# Data Exchange IR to QC

## Description
This project is designed to transfer data between two separate databases, in particular for Quality Control and Additional Data. The transfer can be filtered according to various criteria, such as specific dates, zones, sectors, and a limit on the number of records.

## Prerequisites

- **Node.js**: Version 18 or higher
- **npm**: Minimum version 8, which is bundled with Node.js 18

## Installation

1. **Clone repository:**
   ```bash
   git clone <URL_DU_DEPOT>
   cd data_exchange_IR_QC
   ```

2. **Installing dependencies:**
   ```bash
   npm install
   ```

3. **Configuring environment variables:**
Create an .env file at the root of the project and configure the connection parameters for the databases. :
    ```
    # .env file
    DB1_HOST=localhost
    DB1_PORT=5432
    DB1_USER=username
    DB1_PASSWORD=password
    DB1_DATABASE=database1

    DB2_HOST=localhost
    DB2_PORT=5433
    DB2_USER=username
    DB2_PASSWORD=password
    DB2_DATABASE=database2
    ```

## Use

### Transfer command

To execute the transfer, use the following command:

    ```
    npm run transfer -- [options]
    ```

#### Available options
- --startDate, -s: Start date to filter records (format: YYYY-MM-DDTHH:MM:SS).
- --endDate, -e: End date to filter records (format: YYYY-MM-DDTHH:MM:SS).
- --zone, -z: Filters data by zone attribute in additional_data field.
- --sector, -sec: Filters data by sector attribute in additional_data field.
- --limit, -l: Limits the number of records transferred.

#### Command examples
1. **Transfer with a start date and a limit of 3 records:**
    ```bash
    npm run transfer -- --startDate=2024-10-25T10:00:00 --limit=3
    ```

2. **Transfer with a specific zone and sector:**
    ```bash
    npm run transfer -- --zone="Zone A" --sector="Sector 1"
    ```

3. **Show help:**
    ```bash
    npm run transfer -- --help
    ```

#### How the script works
- Filtering by date: startDate and endDate filter records by period.
- Filtering by zone and sector: zone and sector correspond to sub-attributes in the additional_data JSON field, and the search is case insensitive.
- Limit results: limit allows you to restrict the amount of data transferred.

#### If you need to test differents options:
- npm run transfer -- --startDate=2024-10-25T12:00:00
- npm run transfer -- --endDate=2024-10-25T12:00:00
- npm run transfer -- --zone='Zone A'
- npm run transfer -- --sector='Sector 1'
- npm run transfer -- --limit=3
- npm run transfer -- --startDate=2024-10-25T10:00:00 --endDate=2024-10-25T12:00:00 --zone='Zone A' --sector='Sector 1' --limit=3

### Use the Web Interface

1. **Start the application**:
   ```bash
   npm run start
   ```

2. **Access the interface in your web browser** :
- Navigate to `https://your_host_url:8000` 
- In development mode, use: [http://localhost:8000](http://localhost:8000)

3. **Set filters and send data** 
- Adjust the filters as needed (dates, zones, sectors, etc.) to refine your data selection.
- Click on the Send button to initiate the transfer of Image Review data to Quality Check.

## Dependencies
- Node.js
- PostgreSQL
- dotenv for environment variable management.
- minimist for parsing command-line arguments.
- tsdz-logger for logging.

## Notes
Make sure that the databases are accessible and that the quality_control_data and quality_additional_data tables exist in the respective databases before running the script.

## Contributors
- Main author : Thomas Berteau