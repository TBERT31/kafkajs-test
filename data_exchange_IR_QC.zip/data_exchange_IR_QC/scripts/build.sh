#!/bin/bash -e
cd "$(readlink -f $(dirname $(dirname $0)))"

trap "exit" INT

VERSION=$(grep -oP '(?<="version": ")[^"]*' package.json)
NAME=$(grep -oP '(?<="name": ")[^"]*' package.json)

echo "Génération de $NAME v$VERSION"

npm config set registry https://epm.exyzt.fr/repository/npm/

if [ ! -z $NPM_TOKEN ]; then
    echo "//epm.exyzt.fr/repository/npm/:_authToken=${NPM_TOKEN}" >> ~/.npmrc
else
    npm login
fi

npm ci
npm prune --omit=dev
