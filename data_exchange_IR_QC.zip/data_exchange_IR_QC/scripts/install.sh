#!/bin/bash
cd "$(readlink -f $(dirname $(dirname $0)))"

if [ -f ~/.npmrc ]; then
    NPM_TOKEN=$(grep -oP '(?<=_authToken=).*' ~/.npmrc)
    if [ ! -z $NPM_TOKEN ]; then
        echo "Utilisation du token présent dans le profil utilisateur"
    fi
fi

case $1 in
    docker-image) # build and install docker image
        docker build --build-arg NPM_TOKEN=$NPM_TOKEN -t data_exchange_ir_qc .
    ;;
    install) # build and install dependencies
        docker compose run --entrypoint /bin/bash -e NPM_TOKEN=$NPM_TOKEN dev ./scripts/build.sh .
    ;;
esac
