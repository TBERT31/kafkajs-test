import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import logger from 'tsdz-logger';
import { transferData } from './sendDataFromIRToQC/dataTransfer.js';

const app = express();
const PORT = process.env.PORT || 8000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, 'views/sendDataFromIRToQC')));
app.use('/static', express.static(path.join(__dirname, 'static')));

app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, './views/sendDataFromIRToQC/index.html'));
});

app.post('/transfer-data', async (req, res) => {
    const { startDate, endDate, zone, sector, limit } = req.body;
    
    try {
        await transferData(startDate, endDate, zone, sector, limit);
        res.status(200).json({ message: 'Transfer successful!' });
    } catch (error) {
        logger.error('Error during data transfer:', error);
        res.status(500).json({ message: 'Error during data transfer' });
    }
});

app.listen(PORT, () => {
    logger.info(`Server started on port ${PORT}`);
});
