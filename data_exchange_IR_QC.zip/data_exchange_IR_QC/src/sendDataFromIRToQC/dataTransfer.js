import pkg from 'pg';
import logger from 'tsdz-logger';
import dotenv from 'dotenv';
import { formatDateForPostgres } from '../utils/formatDate.js';

dotenv.config();

const { Client } = pkg;

export async function transferData(
  startDate = null, 
  endDate = null, 
  zone = null, 
  sector = null, 
  limit = null
) {
  const db1Client = new Client({
    host: process.env.DB1_HOST,
    port: process.env.DB1_PORT,
    user: process.env.DB1_USER,
    password: process.env.DB1_PASSWORD,
    database: process.env.DB1_DATABASE,
  });
  
  const db2Client = new Client({
    host: process.env.DB2_HOST,
    port: process.env.DB2_PORT,
    user: process.env.DB2_USER,
    password: process.env.DB2_PASSWORD,
    database: process.env.DB2_DATABASE,
  });
  
  try {
    await db1Client.connect();
    await db2Client.connect();
    
    logger.info('Connected to both databases');

    const formattedStartDate = formatDateForPostgres(startDate);
    const formattedEndDate = formatDateForPostgres(endDate);

    let query = `
      SELECT qc.*, qad.additional_data
      FROM control.quality_control_data qc
      LEFT JOIN control.quality_additional_data qad
      ON qc.control_id = qad.control_id
      WHERE 1=1
    `;
    const queryParams = [];

    if (formattedStartDate) {
      queryParams.push(formattedStartDate);
      query += ` AND qc.assigned_at >= $${queryParams.length}`;
    }
    if (formattedEndDate) {
      queryParams.push(formattedEndDate);
      query += ` AND qc.assigned_at <= $${queryParams.length}`;
    }

    if (zone) {
      queryParams.push(zone.toLowerCase());
      query += ` AND (LOWER(qad.additional_data->'zone'->>'value') = $${queryParams.length} OR LOWER(qad.additional_data->'zone'->>'label') = $${queryParams.length})`;
    }

    if (sector) {
      queryParams.push(sector.toLowerCase());
      query += ` AND (LOWER(qad.additional_data->'sector'->>'value') = $${queryParams.length} OR LOWER(qad.additional_data->'sector'->>'label') = $${queryParams.length})`;
    }

    if (limit !== null && !isNaN(limit) && limit > 0) {  
      query += ` LIMIT $${queryParams.length + 1}`;
      queryParams.push(limit);
    }
  

    logger.info(`Executing query: ${query} with params: ${queryParams}`);

    const res = await db1Client.query(query, queryParams);
    const data = res.rows;

    logger.info(`Recovered data: ${data.length} records`);

    for (const row of data) {
      await db2Client.query(
        `INSERT INTO control.quality_control_data (control_id, city_id, agent_id, assigned_at, done_at, control_data)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (control_id) 
         DO UPDATE SET city_id = $2, agent_id = $3, assigned_at = $4, done_at = $5, control_data = $6`,
        [
          row.control_id,
          row.city_id,
          row.agent_id,
          row.assigned_at,
          row.done_at,
          row.control_data,
        ]
      );

      if (row.additional_data) {
        await db2Client.query(
          `INSERT INTO control.quality_additional_data (control_id, city_id, additional_data)
           VALUES ($1, $2, $3)
           ON CONFLICT (control_id)
           DO UPDATE SET city_id = $2, additional_data = $3`,
          [
            row.control_id,
            row.city_id,
            row.additional_data,
          ]
        );
      }
    }

    logger.info('Data transfer completed successfully');
  } catch (error) {
    logger.error('Error during data transfer:', error);
  } finally {
    await db1Client.end();
    await db2Client.end();
    logger.info('Connections to databases closed');
  }
}