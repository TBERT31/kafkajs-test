import dotenv from 'dotenv';
import minimist from 'minimist';
import { transferData } from './sendDataFromIRToQC/dataTransfer.js';

dotenv.config();

const args = minimist(process.argv.slice(2), {
  string: ['startDate', 'endDate', 'zone', 'sector'],
  integer: ['limit'],
  alias: { startDate: 's', endDate: 'e', zone: 'z', sector: 'sec', limit: 'l' },
  default: { startDate: null, endDate: null, zone: null, sector: null, limit: null }
});

if (args.help) {
  console.log(`
Usage: npm run transfer -- [options]

Options:
  --startDate, -s  Specify the start date for filtering records. Format: YYYY-MM-DDTHH:MM:SS
  --endDate, -e    Specify the end date for filtering records. Format: YYYY-MM-DDTHH:MM:SS
  --zone, -z       Filter by the zone attribute within the additional_data JSON field.
  --sector, -sec   Filter by the sector attribute within the additional_data JSON field.
  --limit, -l      Limit the number of records to transfer.
  --help, -h       Show this help message and exit.

Examples:
  npm run transfer -- --startDate=2024-10-25T10:00:00 --limit=3
  npm run transfer -- --zone="Zone A" --sector="Sector 1" --limit=5

Description:
  This command transfers data from the quality_control_data table in database 1 to database 2.
  You can specify multiple filters to limit the data transferred:
  - Use date range filtering with startDate and endDate.
  - Filter by zone and sector within the additional_data JSON.
  - Limit the transfer to a specified number of records.
  `);
  process.exit(0); 
}

const startDate = args.startDate || null;
const endDate = args.endDate || null;
const zone = args.zone || null;
const sector = args.sector || null;
const limit = args.limit !== null ? parseInt(args.limit, 10) : null;

transferData(startDate, endDate, zone, sector, limit).catch((error) => {
  console.error('Error during data transfer:', error);
});
