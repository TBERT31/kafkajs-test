export function formatDateForPostgres(date) {
    if (!date) return null;
    
    const dateObj = new Date(date);
    
    const formattedDate = dateObj.toLocaleString('sv-SE', { timeZoneName: 'short' });
    
    return formattedDate;
}