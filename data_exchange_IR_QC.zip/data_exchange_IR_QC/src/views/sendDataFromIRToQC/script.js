document.getElementById('transferButton').addEventListener('click', async function() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const limit = document.getElementById('limit').value ? parseInt(document.getElementById('limit').value, 10) : null; 
    const zone = document.getElementById('zone').value;
    const sector = document.getElementById('sector').value;

    const statusElement = document.getElementById('status');
    const loaderElement = document.getElementById('loader');
    const transferButtonElement = document.getElementById('transferButton');

    statusElement.classList.remove('success-message', 'error-message');
    statusElement.innerHTML = "Transferring data...";
    loaderElement.style.display = "inline-block";
    transferButtonElement.style.display = "none";

    try {
        const response = await fetch('/transfer-data', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ startDate, endDate, limit, zone, sector })
        });

        const result = await response.json();

        await new Promise(resolve => setTimeout(resolve, 2000));
        
        if (response.ok) {
            statusElement.innerHTML = "Transfer successful!";
            statusElement.classList.add('success-message');
        } else {
            statusElement.innerHTML = "Error: " + result.message;
            statusElement.classList.add('error-message');
        }
    } catch (error) {
        console.error('Error during data transfer:', error);
        statusElement.innerHTML = "Transfer failed!";
        statusElement.classList.add('error-message');
    } finally {
        loaderElement.style.display = "none";
        transferButtonElement.style.display = "inline-block";
    }
});

document.getElementById('resetButton').addEventListener('click', function() {
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.getElementById('limit').value = ''; 
    document.getElementById('zone').value = '';
    document.getElementById('sector').value = '';
    document.getElementById('status').innerHTML = '';
    document.getElementById('status').classList.remove('success-message', 'error-message');
});
