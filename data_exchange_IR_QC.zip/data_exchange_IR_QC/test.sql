INSERT INTO "control".quality_control_data
(control_id, city_id, agent_id, assigned_at, done_at, control_data)
VALUES
-- Exemple 1
('0fbeb777-9774-4be3-a233-baf905cd8994', '99999999999996', NULL, '2024-10-25 10:15:49.863', NULL, 
'{"type": "LAPI", "state": "ASSIGNED", "userId": "exyztyyy", "agentId": "996", "gpsPdop": "1", "tickets": [], 
"accuracy": "5", "latitude": 43.703277, "metadata": null, "priority": "LOW", "progress": "COMPLETE", 
"validity": "INVALID", "controlId": "0fbeb777-9774-4be3-a233-baf905cd8994", "expiresAt": "2024-10-25T12:33:58.751Z", 
"longitude": 7.268863, "transitId": "b01899b9-1e66-485d-97f3-b328a863a4ca", "gpsHeading": "0", "terminalId": "exyzt", 
"controlDate": "2024-10-24T12:33:58.751Z", "parkingType": null, "licensePlate": "ZZ123ZZ", "plateCountry": null, "platePicture": 
"plate_picture.jpeg", "vehicleBrand": null, "vehicleModel": null, "messengerSent": false, "emitterGpsPdop": null, 
"genReliability": "1", "charReliability": [0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8], 
"contextPictures": ["pano_image_9.jpg", "pano_image_3.jpg", "pano_image_5.jpg", "pano_image_6.jpg", 
"anpr_image_color.jpg", "pano_image_2.jpg", "pano_image_8.jpg", "pano_image_1.jpg", "pano_image_7.jpg", "pano_image_4.jpg"], 
"emitterLatitude": null, "parkingCategory": null, "vehicleCategory": null, "emitterLongitude": null, 
"licensePlateHash": "b719e0dc7793ba1638a772aad84264d2dd7aeff654be6526b50e9168eb390da3", "plateCountryIvrc": null, 
"emitterGpsHeading": null, "filteredByDuplicate": null, "filteredByMapMatching": null, "filteredByMessengerDecision": null}'::jsonb),

-- Exemple 2
('123e4567-e89b-12d3-a456-426614174001', '99999999999997', NULL, '2024-10-25 11:20:30', NULL, 
'{
  "type": "MANUAL", "state": "PENDING", "userId": "agent001", "agentId": "101", "gpsPdop": "0.9", "tickets": ["ticket123"],
  "accuracy": "4", "latitude": 40.748817, "metadata": {"shift": "morning"}, "priority": "HIGH", "progress": "ONGOING",
  "validity": "VALID", "controlId": "123e4567-e89b-12d3-a456-426614174001", "expiresAt": "2024-10-25T14:20:30Z",
  "longitude": -73.985428, "transitId": "transit001", "gpsHeading": "180", "terminalId": "terminal001",
  "controlDate": "2024-10-25T10:20:30Z", "parkingType": "street", "licensePlate": "XY123YX", "plateCountry": "FR",
  "platePicture": "plate_pic1.jpeg", "vehicleBrand": "Toyota", "vehicleModel": "Corolla", "messengerSent": true,
  "genReliability": "0.98", "charReliability": [0.9, 0.9, 0.9], "contextPictures": ["img_1.jpg", "img_2.jpg"]
}'::jsonb),

-- Exemple 3
('123e4567-e89b-12d3-a456-426614174002', '99999999999998', NULL, '2024-10-25 12:00:00', NULL, 
'{
  "type": "AUTOMATIC", "state": "ASSIGNED", "userId": "agent002", "agentId": "102", "gpsPdop": "1.1", "tickets": [],
  "accuracy": "3", "latitude": 51.507351, "metadata": {"shift": "afternoon"}, "priority": "LOW", "progress": "PENDING",
  "validity": "VALID", "controlId": "123e4567-e89b-12d3-a456-426614174002", "expiresAt": "2024-10-25T15:00:00Z",
  "longitude": -0.127758, "transitId": "transit002", "gpsHeading": "90", "terminalId": "terminal002",
  "controlDate": "2024-10-25T11:00:00Z", "parkingType": "garage", "licensePlate": "AB456CD", "plateCountry": "DE",
  "platePicture": "plate_pic2.jpeg", "vehicleBrand": "BMW", "vehicleModel": "320i", "messengerSent": false,
  "genReliability": "0.95", "charReliability": [0.85, 0.85, 0.85], "contextPictures": ["img_3.jpg"]
}'::jsonb),

-- Exemple 4
('123e4567-e89b-12d3-a456-426614174003', '99999999999999', NULL, '2024-10-25 13:30:15', NULL, 
'{
  "type": "MANUAL", "state": "COMPLETED", "userId": "agent003", "agentId": "103", "gpsPdop": "0.7", "tickets": ["ticket234", "ticket235"],
  "accuracy": "2", "latitude": 48.856613, "metadata": null, "priority": "MEDIUM", "progress": "COMPLETE",
  "validity": "INVALID", "controlId": "123e4567-e89b-12d3-a456-426614174003", "expiresAt": "2024-10-25T16:30:15Z",
  "longitude": 2.352222, "transitId": "transit003", "gpsHeading": "270", "terminalId": "terminal003",
  "controlDate": "2024-10-25T12:30:15Z", "parkingType": "public", "licensePlate": "JK789LM", "plateCountry": "IT",
  "platePicture": "plate_pic3.jpeg", "vehicleBrand": "Audi", "vehicleModel": "A4", "messengerSent": false,
  "genReliability": "0.92", "charReliability": [0.75, 0.75, 0.75], "contextPictures": ["img_4.jpg", "img_5.jpg"]
}'::jsonb),

-- Exemple 5
('123e4567-e89b-12d3-a456-426614174004', '99999999999995', NULL, '2024-10-25 14:45:10', NULL, 
'{
  "type": "LAPI", "state": "ASSIGNED", "userId": "agent004", "agentId": "104", "gpsPdop": "1.2", "tickets": [],
  "accuracy": "1", "latitude": 34.052235, "metadata": null, "priority": "LOW", "progress": "ONGOING",
  "validity": "VALID", "controlId": "123e4567-e89b-12d3-a456-426614174004", "expiresAt": "2024-10-25T17:45:10Z",
  "longitude": -118.243683, "transitId": "transit004", "gpsHeading": "0", "terminalId": "terminal004",
  "controlDate": "2024-10-25T13:45:10Z", "parkingType": "private", "licensePlate": "MN012OP", "plateCountry": "ES",
  "platePicture": "plate_pic4.jpeg", "vehicleBrand": "Mercedes", "vehicleModel": "C-Class", "messengerSent": true,
  "genReliability": "0.88", "charReliability": [0.8, 0.8, 0.8], "contextPictures": ["img_6.jpg", "img_7.jpg"]
}'::jsonb),

-- Exemple 6
('123e4567-e89b-12d3-a456-426614174005', '99999999999994', NULL, '2024-10-25 15:15:20', NULL, 
'{
  "type": "AUTOMATIC", "state": "COMPLETED", "userId": "agent005", "agentId": "105", "gpsPdop": "1.5", "tickets": ["ticket456"],
  "accuracy": "3", "latitude": 35.689487, "metadata": null, "priority": "HIGH", "progress": "COMPLETE",
  "validity": "VALID", "controlId": "123e4567-e89b-12d3-a456-426614174005", "expiresAt": "2024-10-25T18:15:20Z",
  "longitude": 139.691711, "transitId": "transit005", "gpsHeading": "180", "terminalId": "terminal005",
  "controlDate": "2024-10-25T14:15:20Z", "parkingType": "street", "licensePlate": "QR345ST", "plateCountry": "JP",
  "platePicture": "plate_pic5.jpeg", "vehicleBrand": "Honda", "vehicleModel": "Civic", "messengerSent": false,
  "genReliability": "0.9", "charReliability": [0.8, 0.85, 0.8], "contextPictures": ["img_8.jpg"]
}'::jsonb),

-- Exemple 7
('123e4567-e89b-12d3-a456-426614174006', '99999999999993', NULL, '2024-10-25 16:25:00', NULL, 
'{
  "type": "MANUAL", "state": "ASSIGNED", "userId": "agent006", "agentId": "106", "gpsPdop": "1.3", "tickets": ["ticket567", "ticket568"],
  "accuracy": "2", "latitude": 52.520008, "metadata": {"shift": "night"}, "priority": "MEDIUM", "progress": "ONGOING",
  "validity": "VALID", "controlId": "123e4567-e89b-12d3-a456-426614174006", "expiresAt": "2024-10-25T19:25:00Z",
  "longitude": 13.404954, "transitId": "transit006", "gpsHeading": "45", "terminalId": "terminal006",
  "controlDate": "2024-10-25T15:25:00Z", "parkingType": "garage", "licensePlate": "UV678WX", "plateCountry": "FR",
  "platePicture": "plate_pic6.jpeg", "vehicleBrand": "Volkswagen", "vehicleModel": "Golf", "messengerSent": true,
  "genReliability": "0.85", "charReliability": [0.7, 0.7, 0.7], "contextPictures": ["img_9.jpg", "img_10.jpg"]
}'::jsonb);



----------------------------------------------------------------

INSERT INTO "control".quality_additional_data (control_id, city_id, additional_data) VALUES

-- Exemple 1
('0fbeb777-9774-4be3-a233-baf905cd8994', '99999999999996', 
'{
  "plate": "ZZ123ZZ",
  "country": {"id": "FR", "label": "France", "value": "France"},
  "vehicleCategory": {"label": "Passenger Vehicle", "value": "passenger"},
  "brand": {"id": "Renault", "label": "Renault", "value": "Renault"},
  "model": {"id": "Clio", "label": "Clio", "value": "Clio"},
  "position": {"lon": 7.268863, "lat": 43.703277},
  "zone": {"label": "Downtown Zone", "value": "Zone A"},
  "sector": {"label": "East", "value": "Sector 1"},
  "address": "1 Promenade des Anglais",
  "postalCode": "06000",
  "city": "Nice",
  "mediasUrl": ["pano_image_1.jpg", "pano_image_2.jpg", "plate_picture.jpeg"]
}'::json),

-- Exemple 2
('123e4567-e89b-12d3-a456-426614174001', '99999999999997', 
'{
  "plate": "XY123YX",
  "country": {"id": "FR", "label": "France", "value": "France"},
  "vehicleCategory": {"label": "SUV", "value": "SUV"},
  "brand": {"id": "Toyota", "label": "Toyota", "value": "Toyota"},
  "model": {"id": "Corolla", "label": "Corolla", "value": "Corolla"},
  "position": {"lon": -73.985428, "lat": 40.748817},
  "zone": {"label": "City Center", "value": "Zone B"},
  "sector": {"label": "North", "value": "Sector 2"},
  "address": "5th Ave",
  "postalCode": "10001",
  "city": "New York",
  "mediasUrl": ["img_1.jpg", "img_2.jpg", "plate_pic1.jpeg"]
}'::json),

-- Exemple 3
('123e4567-e89b-12d3-a456-426614174002', '99999999999998', 
'{
  "plate": "AB456CD",
  "country": {"id": "DE", "label": "Germany", "value": "Germany"},
  "vehicleCategory": {"label": "Sedan", "value": "sedan"},
  "brand": {"id": "BMW", "label": "BMW", "value": "BMW"},
  "model": {"id": "320i", "label": "320i", "value": "320i"},
  "position": {"lon": -0.127758, "lat": 51.507351},
  "zone": {"label": "Financial District", "value": "Zone C"},
  "sector": {"label": "West", "value": "Sector 3"},
  "address": "10 Downing St",
  "postalCode": "SW1A 2AA",
  "city": "London",
  "mediasUrl": ["img_3.jpg", "plate_pic2.jpeg"]
}'::json),

-- Exemple 4
('123e4567-e89b-12d3-a456-426614174003', '99999999999999', 
'{
  "plate": "JK789LM",
  "country": {"id": "IT", "label": "Italy", "value": "Italy"},
  "vehicleCategory": {"label": "Luxury Vehicle", "value": "luxury"},
  "brand": {"id": "Audi", "label": "Audi", "value": "Audi"},
  "model": {"id": "A4", "label": "A4", "value": "A4"},
  "position": {"lon": 2.352222, "lat": 48.856613},
  "zone": {"label": "Historic Center", "value": "Zone D"},
  "sector": {"label": "South", "value": "Sector 4"},
  "address": "Rue de Rivoli",
  "postalCode": "75001",
  "city": "Paris",
  "mediasUrl": ["img_4.jpg", "img_5.jpg", "plate_pic3.jpeg"]
}'::json),

-- Exemple 5
('123e4567-e89b-12d3-a456-426614174004', '99999999999995', 
'{
  "plate": "MN012OP",
  "country": {"id": "ES", "label": "Spain", "value": "Spain"},
  "vehicleCategory": {"label": "Commercial Vehicle", "value": "commercial"},
  "brand": {"id": "Mercedes", "label": "Mercedes", "value": "Mercedes"},
  "model": {"id": "C-Class", "label": "C-Class", "value": "C-Class"},
  "position": {"lon": -118.243683, "lat": 34.052235},
  "zone": {"label": "Business District", "value": "Zone E"},
  "sector": {"label": "Central", "value": "Sector 5"},
  "address": "Sunset Blvd",
  "postalCode": "90028",
  "city": "Los Angeles",
  "mediasUrl": ["img_6.jpg", "img_7.jpg", "plate_pic4.jpeg"]
}'::json),

-- Exemple 6
('123e4567-e89b-12d3-a456-426614174005', '99999999999994', 
'{
  "plate": "QR345ST",
  "country": {"id": "JP", "label": "Japan", "value": "Japan"},
  "vehicleCategory": {"label": "Compact", "value": "compact"},
  "brand": {"id": "Honda", "label": "Honda", "value": "Honda"},
  "model": {"id": "Civic", "label": "Civic", "value": "Civic"},
  "position": {"lon": 139.691711, "lat": 35.689487},
  "zone": {"label": "Commercial Area", "value": "Zone F"},
  "sector": {"label": "North East", "value": "Sector 6"},
  "address": "Shibuya",
  "postalCode": "150-0002",
  "city": "Tokyo",
  "mediasUrl": ["img_8.jpg", "plate_pic5.jpeg"]
}'::json),

-- Exemple 7
('123e4567-e89b-12d3-a456-426614174006', '99999999999993', 
'{
  "plate": "UV678WX",
  "country": {"id": "FR", "label": "France", "value": "France"},
  "vehicleCategory": {"label": "Hatchback", "value": "hatchback"},
  "brand": {"id": "Volkswagen", "label": "Volkswagen", "value": "Volkswagen"},
  "model": {"id": "Golf", "label": "Golf", "value": "Golf"},
  "position": {"lon": 13.404954, "lat": 52.520008},
  "zone": {"label": "Residential Area", "value": "Zone G"},
  "sector": {"label": "East", "value": "Sector 7"},
  "address": "Alexanderplatz",
  "postalCode": "10178",
  "city": "Berlin",
  "mediasUrl": ["img_9.jpg", "img_10.jpg", "plate_pic6.jpeg"]
}'::json);
