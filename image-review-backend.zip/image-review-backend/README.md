# Stade Control WebService

### Cycle de vie d'un contrôle

```mermaid
graph TB
	NEW["Nouveau contrôle"]
	PENDING["Attente de décision <br/> (status &#61; PENDING)"]
	PROCESSING["Assigné à un agent <br/> (status &#61; PROCESSING)"]
	EXPIRED["Contrôle hors delai <br/> (decision &#61; EXPIRED)"]
	DECISION["Décision prise <br/> (status &#61; DONE) <br/> (decision &#61; (EMIT-NFPS|EMIT-FPS|...))"]
	NEW -- "insertion control" --> PENDING
	PENDING -- "assignation agent" --> PROCESSING
	PENDING -- "supression controle\n insertion control_result" --> EXPIRED
	PROCESSING -- "desasignation agent\n supression controle\n insertion control_result" --> EXPIRED
	PROCESSING -- "insertion control_result" --> DECISION
	PROCESSING -- "desasignation agent" --> PENDING
```

### Installation et démarrage

```bash
npm install
npm run build
npm run start
```

### Notes de mise à jour

# v2.2.0
Mettre à jour le .env avec la valeur suivante
```
TICKET_DISPATCHER_ENDPOINT=https://dispatcher-ticket-endpoint.local
```

Ajouter sur toutes les villes le rôle ROLE_TICKETS_VERIFY sur le compte api utilisé.
