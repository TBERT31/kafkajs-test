#!/bin/bash -e

if [ -z "$ENTRYPOINT_COMMAND" ]; then
	COMMAND="./$(basename "$0")"
else
	COMMAND="$(bash -c "echo \"$ENTRYPOINT_COMMAND\"")"
fi

help() {
	echo NAME
	echo "	$COMMAND - $2"
	echo
	echo SYNOPSIS
	echo "	$COMMAND [option]"
	echo
	echo OPTIONS

	COMMAND=$(cat "$1" | grep ") #" | tail -n +2 | sed -e "s/\s*\(.*\)) #/\1/")
	LEN=$(echo "$COMMAND" | cut -d' ' -f1 | wc -L)
	echo "$COMMAND" | awk '{$1 = sprintf("%-*s\t", '$LEN', $1)} 1'
}

if [ "${1#-}" != "${1}" ] || [ -z "$(command -v "${1}")" ] || { [ -f "${1}" ] && ! [ -x "${1}" ]; }; then
	set -- npm run start -- "${@:1}"
else
	case $1 in
	  start) # run start command
		  set -- npm run start -- "${@:2}"
		  ;;
	  history-cleanup) # run history-cleanup command
		  set -- npm run start -- history-cleanup "${@:2}"
		  ;;
	  additional-data-cleanup) # run additional-data-cleanup command
		  set -- npm run start -- additional-data-cleanup "${@:2}"
		  ;;
	  help) # display help
	      help "$(readlink -f "$0")" "$(node -e "console.log(require('$(dirname "$0")/package.json').description)")"
		  exit 0
	    ;;
	esac
fi

exec "$@"
