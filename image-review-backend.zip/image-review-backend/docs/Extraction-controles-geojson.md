# Extraction des controles au format GeoJSON

Nous allons extraire la liste des controles effectués au format GeoJSON depuis les logs d'activit sur les controles.
Les données cibles sont :

- Une Geometry, selon la latitude et longitude
- La date du controle, au moment de la capture LAPI
- Le statut du controle depuis le service de controle Image Review
- La plaque d'immatriculation
- L'ID du controle LAPI

A cet effet, nous allons avoir besoin de Postgis qui - a ce jour - n'est pas installé sur le servuer Postgres de production. Nous allons donc travailler sur une base de données locale beneficiant de l'extention Postgis pour l'instant.

Nous devrons donc, dans cet ordre :

- Extraire les données des logs de la ville nous interessant au format SQL
- Telecharger les données en local
- Purger notre base de données locale
- Importer les données de logs des controles
- Generer l'export GeoJSON.

Les exeples illustrés ci dessous se font avec le siret de Montpellier dans le cadre de la demo TAM.

## Extraction des logs de controles :

Les données de logs sont extraites depuis la table `control.control_logs`.
Nous extrayons uniquement les logs d'un code ville donné et dont la date est supérieure a une date donnée.  
Dans cet exemple, nous extrayons tous les logs de la ville `11111111111116` dont l'enregistrement s'est fait apres le 6 Janvier 2021 a midi :

```sql
COPY (select * from "control".controls_logs cl
	where cl.after_content->>'city_id' = '11111111111116'
	and cl.logtime > TO_TIMESTAMP(
    '2021-01-06 12:00:20',
    'YYYY-MM-DD HH24:MI:SS'
)) TO '/var/lib/postgresql/export.sql';
```

> **NB : Le chemin d'export doit etre un dossier dont l'utilisateur UNIX `postgres` à accès. Afin de pouvoir exporter dans le dossier `/var/lib/postgresql` il faut un compte Super Admin sur la BDD postgres.  
> Ici nous sommes passés avec la commande `psql` apres une elevation de privilèges depuis une connexion SSH. _(user -> root -> postgres -> `psql`)_**

## Téléchargement

Le telechargement de l'archive d'export s'est faite au travers d'une connexion SFTP.

## Purge de la BDD locale

Afin d'éviter de polluer nos données avec des résidus de donnees de developpement, nous allons purger notre table `control.controls_logs`:

```sql
TRUCATE "control".controls_logs RESTART IDENTITY;
```

## Import de l'archive SQL

Depuis la base de données locale, avec un compte Super Admin :

```sql
COPY "control".controls_logs FROM '/path/to/file/export.sql'
```

Les données sont à présent chargées.

## Extract & export au format GeoJSON :

A présent nous allons - à l'aide de Postgis - générer un GeoJSON d'après le **dernier log en date de chaque controle**.  
A l'instar des données de logs, nous extrayons ce dernier dans `/var/lib/postgresql` :

```sql
copy (
	select
	json_build_object(
	    'type', 'FeatureCollection',
	    'features', json_agg(ST_AsGeoJSON(t.*)::json)
	) as geojson
	from (
		select distinct on (sq.control_id) * from (
			select
				cl.after_content->>'control_id' as control_id,
				ST_SetSRID(
					ST_MakePoint(
						(cl.after_content#>'{control_data,gps_longitude}')::text::double precision,
						(cl.after_content#>'{control_data,gps_latitude}')::text::double precision
					),
				4326) as geom,
				cl.after_content->>'city_id' as city_id,
				cl.after_content->>'status' as status,
				cl.after_content#>'{control_data,plate}' as plate,
				cl.after_content#>'{control_data,date}' as control_date,
				cl.after_content#>'{control_data,licensePlateHash}' as plate_hash
			from "control".controls_logs cl
			where cl.after_content->>'city_id' = '11111111111116'
			order by cl.logtime desc
		) sq
	--	limit 10
	) as t(id, geom, "cityId", status, plate, "controlDate", "hashedPlate")
)
to '/var/lib/postgresql/geojson.json'
```
