
--------- ADDING NEW TABLES
CREATE SCHEMA "control";

CREATE TABLE "control".assigned_controls (
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
	agent_id varchar NULL,
	assigned_at timestamptz NULL,
	done_at timestamptz NULL,
	control_data jsonb not null,
	CONSTRAINT assigned_controls_pk PRIMARY KEY (control_id)
);

CREATE TABLE "control".decisions_history (
	id SERIAL,
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
	lapi_id varchar NOT NULL,
	agent_id varchar NULL,
	decision varchar NOT NULL,
	payload jsonb null,
	status varchar not NULL,
	created_at timestamptz NOT NULL DEFAULT now(),
	assigned_at timestamptz NULL,
	submitted_at timestamptz NULL,
	done_at timestamptz NULL,
	vehicle_category VARCHAR null,
	CONSTRAINT control_results_pk PRIMARY KEY (id)
);

CREATE TABLE "control".decisions_history_quality (
	id SERIAL,
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
	lapi_id varchar NOT NULL,
	agent_id_ir varchar NULL,
	agent_id_quality varchar NULL,
	decision varchar NOT NULL,
	payload jsonb null,
	status varchar not NULL,
	created_at timestamptz NOT NULL DEFAULT now(),
	assigned_at timestamptz NULL,
	submitted_at timestamptz NULL,
	done_at timestamptz NULL,
	vehicle_category VARCHAR null,
	CONSTRAINT control_results_pk PRIMARY KEY (id)
);

CREATE TABLE "control".additional_data (
	control_id varchar NOT NULL,
	created_at timestamptz DEFAULT NOW(),
	city_id varchar NOT NULL,
    additional_data jsonb NOT null default '{}'::jsonb,
	CONSTRAINT additional_data_pk PRIMARY KEY (control_id)
);

CREATE INDEX decisions_history_control_id_idx ON control.decisions_history (control_id);
CREATE INDEX decisions_history_submitted_at_idx ON control.decisions_history (submitted_at);
CREATE INDEX additional_data_created_at_idx ON control.additional_data (created_at);


--------- TABLES FOR QUALITY CHECKS

CREATE SCHEMA "quality_check";

CREATE TABLE "quality_check".qc_assigned_controls (
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
	agent_id varchar NULL, 
	agent_id_in_image_review varchar NOT NULL,  
	assigned_at timestamptz NULL, 
	assigned_at_in_image_review timestamptz NULL, 
	done_at timestamptz NULL, 
	done_at_in_image_review timestamptz NULL, 
	control_data jsonb not null, 
	CONSTRAINT assigned_controls_quality_pk PRIMARY KEY (control_id)
);

