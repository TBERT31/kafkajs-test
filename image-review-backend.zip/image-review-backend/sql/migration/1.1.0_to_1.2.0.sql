ALTER TABLE "control".controls ADD control_data jsonb NOT NULL;
ALTER TABLE "control".controls ADD additional_data jsonb NOT null default '{}'::jsonb;

CREATE OR REPLACE FUNCTION "control".GDPRizeControlLog(id varchar)
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE "control".controls_logs
    SET
      before_content = regexp_replace(before_content::text, '(plate|licensePlate)": "[a-zA-Z0-9]+"', '\1": null')::jsonb,
	    after_content = regexp_replace(after_content::text, '(plate|licensePlate)": "[a-zA-Z0-9]+"', '\1": null')::jsonb
    WHERE
      before_content->>'control_id' = $1 OR
      after_content->>'control_id' = $1
  ;
	return true;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION "control".log_control_change() RETURNS TRIGGER AS $lctrlchange$
  BEGIN
    --
    -- Create a row in controls_logs to reflect the operation performed on emp,
    -- make use of the special variable TG_OP to work out the operation.
    --
    IF (TG_OP = 'DELETE') THEN
      INSERT INTO "control".controls_logs SELECT 'DELETE', NOW(), user, ROW_TO_JSON(OLD.*), NULL;
      INSERT INTO "control".control_results SELECT OLD.control_id, OLD.lapi_id, OLD.city_id, OLD.agent_id, 'EXPIRED', OLD.created_at, OLD.assigned_at, NULL, NOW();
      PERFORM "control".GDPRizeControlLog(OLD.control_id);
      RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
      INSERT INTO "control".controls_logs SELECT 'UPDATE', NOW(), user, ROW_TO_JSON(OLD.*), ROW_TO_JSON(NEW.*);
      RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
      INSERT INTO "control".controls_logs SELECT 'INSERT', NOW(), user, NULL, ROW_TO_JSON(NEW.*);
      RETURN NEW;
    END IF;
    RETURN NULL; -- result is ignored since this is an AFTER trigger
  END;
$lctrlchange$ LANGUAGE plpgsql;