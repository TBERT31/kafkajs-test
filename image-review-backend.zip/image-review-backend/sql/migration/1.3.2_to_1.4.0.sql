ALTER TABLE "control".controls ADD COLUMN message jsonb;
ALTER TABLE "control".controls ADD COLUMN decision_payload jsonb;
ALTER TYPE control.control_status ADD VALUE 'SENDING' AFTER 'PROCESSING';

CREATE INDEX ON "control".controls_logs ((after_content->>'control_id'));
CREATE INDEX ON "control".controls_logs ((after_content->>'created_at'));
CREATE INDEX ON "control".controls_logs ((after_content->>'expires_at'));
CREATE INDEX ON "control".controls_logs ((after_content->>'city_id'));

CREATE INDEX ON "control".controls_logs ((before_content->>'control_id'));
CREATE INDEX ON "control".controls_logs ((before_content->>'created_at'));
CREATE INDEX ON "control".controls_logs ((before_content->>'expires_at'));
CREATE INDEX ON "control".controls_logs ((before_content->>'city_id'));

CREATE INDEX ON "control".controls_logs ((logtime));