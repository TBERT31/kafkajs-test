--------- DROPING OLD DB STRUCTURE
DROP SCHEMA IF EXISTS "control" CASCADE;

-- DROP TABLE IF EXISTS control.controls, control.controls_logs CASCADE;

--------- ADDING NEW TABLES
CREATE SCHEMA IF NOT EXISTS "control";

CREATE TABLE IF NOT EXISTS "control".assigned_controls (
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
	agent_id varchar NULL,
	assigned_at timestamptz NULL,
	done_at timestamptz NULL,
	control_data jsonb not null,
	CONSTRAINT assigned_controls_pk PRIMARY KEY (control_id)
);

CREATE TABLE IF NOT EXISTS "control".decisions_history (
  id SERIAL,
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
  lapi_id varchar NOT NULL,
	agent_id varchar NULL,
	decision varchar NOT NULL,
	payload jsonb null,
	status varchar not NULL,
	created_at timestamptz NOT NULL DEFAULT now(),
  assigned_at timestamptz NULL,
  submitted_at timestamptz NULL,
  done_at timestamptz NULL,
	CONSTRAINT control_results_pk PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS "control".additional_data (
	control_id varchar NOT NULL,
	city_id varchar NOT NULL,
    additional_data jsonb NOT null default '{}'::jsonb,
	CONSTRAINT additional_data_pk PRIMARY KEY (control_id)
);