CREATE INDEX CONCURRENTLY IF NOT EXISTS decisions_history_control_id_idx ON control.decisions_history (control_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS decisions_history_submitted_at_idx ON control.decisions_history (submitted_at);
