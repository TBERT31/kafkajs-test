ALTER TABLE "control".additional_data ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX additional_data_created_at_idx ON control.additional_data (created_at);