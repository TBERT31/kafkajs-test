import { app } from './index';
import { startKafkaConsumers } from './kafka/kafkaConsumers';
import logger from 'tsdz-logger';

async function startApp() {
    try {
        await startKafkaConsumers(); 
        await app(); 
    } catch (err) {
        logger.error(`command execution error ${err.message}`, err);
        process.exit(1);
    }
}

startApp();