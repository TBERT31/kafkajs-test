import { Argv } from "yargs";
import computeMinRetentionDate from "../utils/computeMinRetentionDate";
import pool from "../utils/db";
import logger from "../utils/logger";

export interface AdditionalDataCleanupArgs {
	"retention-delay-in-days"?: number;
}

export function additionalDataCleanupArgs(yargs: Argv): Argv<AdditionalDataCleanupArgs> {
	return yargs.number("retention-delay-in-days");
}

export async function additionalDataCleanup(args: AdditionalDataCleanupArgs) {
	const retentionDelay = Number(
		args["retention-delay-in-days"] || process.env.RETENTION_DELAY_IN_DAYS
	);

	if (retentionDelay === undefined) {
		throw new Error(`Retention delay not provided`);
	}

	if (Number.isNaN(retentionDelay)) {
		throw new Error(`Invalid retention delay (expected a number, got ${retentionDelay})`);
	}

	const minRetentionDate = computeMinRetentionDate(retentionDelay);

	const res = await pool.query('DELETE FROM "control".additional_data  WHERE created_at < $1', [
		minRetentionDate,
	]);

	await pool.end();

	logger.info(`${res.rowCount} additional_data deleted`);
}
