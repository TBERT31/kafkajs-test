import { Argv } from "yargs";
import computeMinRetentionDate from "../utils/computeMinRetentionDate";
import pool from "../utils/db";
import logger from "../utils/logger";

export interface HistoryCleanupArgs {
	"retention-delay-in-days"?: number;
}

export function historyCleanupArgs(yargs: Argv): Argv<HistoryCleanupArgs> {
	return yargs.number("retention-delay-in-days");
}

export async function historyCleanup(args: HistoryCleanupArgs) {
	const retentionDelay = Number(
		args["retention-delay-in-days"] || process.env.RETENTION_DELAY_IN_DAYS
	);

	if (retentionDelay === undefined) {
		throw new Error(`Retention delay not provided`);
	}

	if (Number.isNaN(retentionDelay)) {
		throw new Error(`Invalid retention delay (expected a number, got ${retentionDelay})`);
	}

	const minRetentionDate = computeMinRetentionDate(retentionDelay);

	const res = await pool.query('DELETE FROM "control".decisions_history  WHERE created_at < $1', [
		minRetentionDate,
	]);

	await pool.end();

	logger.info(`${res.rowCount} decisions_history deleted`);
}
