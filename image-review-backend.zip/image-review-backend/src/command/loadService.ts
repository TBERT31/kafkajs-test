import bodyParser from "body-parser";
import cors from "cors";

import dotenv from "dotenv";
import errorHandler from "errorhandler";
import express, { Express } from "express";
import { Argv } from "yargs";
import controlRouter from "../components/control/controlController";
import debugRouter from "../components/debug/debugRouter";
import statisticsRouter from "../components/statistics/statisticsRouter";
import logger from "../utils/logger";
import json from "../utils/package";
import { DEBUG, PORT } from "../utils/secrets";

dotenv.config();

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface ServiceArgs {}

export function serviceArgs(yargs: Argv): Argv<ServiceArgs> {
	return yargs.demandOption("config", "config file location").string("config");
}

async function bootstrap(args: ServiceArgs, app: Express) {
	// Configuration.
	app.set("port", PORT);
	app.use(cors({ origin: "*" }));
	app.use(bodyParser.json());
	app.use(bodyParser.urlencoded({ extended: true }));

	if (DEBUG) app.use("/debug", debugRouter);
	app.use("/control", controlRouter);
	app.use("/stats", statisticsRouter);

	app.get("/api/alive", async (req, res) => {
		return res.status(200).json({
			name: json.name,
			version: json.version,
			currentDate: new Date().toISOString(),
			aliveSince: Math.floor(process.uptime() * 1000),
			hostname: process.env.HOSTNAME || "Unknow Hostname",
		});
	});

	// Development helpers.
	if (app.get("env") !== "production") {
		app.use(errorHandler()); // Error handler that provides full stack.
	}
}

export async function loadService(args: ServiceArgs) {
	const app = express();
	await bootstrap(args, app);
	app.listen(PORT);
	logger.info(`listen on http://localhost:${PORT}`, undefined, "service.startup");
}
