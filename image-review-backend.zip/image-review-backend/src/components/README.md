# src/components folder

You can structure your solution by self-contained components here.

[Structure your solution by components](https://github.com/goldbergyoni/nodebestpractices/blob/master/sections/projectstructre/breakintcomponents.md)
