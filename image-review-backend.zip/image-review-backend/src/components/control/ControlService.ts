import moment from "moment";
import logger, { event } from "tsdz-logger";
import { monit } from "tsdz-logger";
import { sendKafkaMessage } from "../../kafka/kafkaSetup";
import { getCityConfigs } from "../../utils/citiesConfigs";
import citiesConfig from "../../utils/configs";
import { CONTROL_SERVICE_IMG_ENDPOINT, ASSIGNATION_QUEUE_TIMEOUT } from "../../utils/secrets";
import {
	ControlState,
	ControlValidity,
	ControlAdditionalData,
	DecisionStatus,
	ErrorMessage,
	JsonControl,
	ResponseControl,
} from "./controlModel";
import {
	assignAgent,
	addAdditionalData,
	addAdditionalDataForQualityCheck,
	getAdditionalData,
	getAssignedControl,
	unassignAgent,
	getLastDecisionHistory,
	assignQualityControlToAgent,
	updateAdditionalDataForQualityCheck,
} from "./controlRepository";
import { getAndAssignControl, patchControl, createPlateHash } from "./controlUtil";
import { checkControlValidity } from "./ticketUtils";

export function buildPictureURI(cityId: string, controlId: string, filename: string) {
	return `${CONTROL_SERVICE_IMG_ENDPOINT}/api/v1/${cityId}/control/${controlId}/pictures/${filename}`;
}

export function convertControl(
	control: ResponseControl,
	cityId: string,
	agentId: string,
	validity: number,
	additionalData: ControlAdditionalData = {},
	assignedAt: string = new Date().toISOString()
): JsonControl {
	return {
		controlId: control.controlId,
		control: {
			vehicle_category: control.vehicleCategory,
			plate_country: control.plateCountry,
			vehicle_brand: control.vehicleBrand,
			vehicle_model: control.vehicleModel,
			id: control.controlId,
			char_reliability: control.charReliability,
			date: control.controlDate,
			gen_reliability: control.genReliability,
			gps_latitude: control.latitude,
			gps_longitude: control.longitude,
			gps_pdop: control.gpsPdop,
			plate: control.licensePlate,
			user_id: control.userId,
			vehicle_id: control.terminalId,
			_rev: control.controlId,
			gps_heading: control.gpsHeading,
			pano_image: control.contextPictures.map((img) => ({
				camera_id: "undefined",
				image: buildPictureURI(cityId, control.controlId, img),
				thumbnail: `${buildPictureURI(cityId, control.controlId, img)}?width=1024&height=768`,
				filename: img,
			})),
			plate_image: buildPictureURI(cityId, control.controlId, control.platePicture),
			progress: control.progress,
			status: control.validity,
			tickets: control.tickets,
			transit_id: control.transitId,
		},
		additionalData: additionalData,
		message: control.metadata ? (JSON.parse(control.metadata) as ErrorMessage) : null,
		cityId,
		createdAt: control.controlDate,
		doneAt: null,
		expiresAt:
			control.expiresAt || moment(control.controlDate).add(validity, "seconds").toISOString(),
		lapiId: control.userId,
		agentId,
		status: control.state,
		assignedAt: assignedAt,
	};
}

/**
 * Adding control state for better tracking of
 */
async function getNewControl(
	cityId: string,
	agentId: string,
	state: { requestState?: string; timeout?: boolean } = {
		requestState: "0.0 - BEGIN",
	}
): Promise<JsonControl | undefined> {
	if (state.timeout) {
		event(`Asignation canceled`);
		return undefined;
	}

	state.requestState = "1.0.2 - GET_CITY_CONFIG";
	const cityConfig = await getCityConfigs(cityId);

	event("get control");
	/**
	 * No control found,
	 */
	state.requestState = "1.0.3 - GET_AND_ASSIGNED_CONTROL";
	const control = await getAndAssignControl(agentId, cityId, cityConfig);

	if (!control) return undefined;

	const { controlId } = control;
	const controlInfos = { cityId, agentId, controlId };

	/**
	 * 2.0 - check if control still invalid
	 */
	if (control.validity.toUpperCase() == ControlValidity.INVALID) {
		event("check control validity", { controlId });
		const ticketsRes = await checkControlValidity(cityId, control);
		logger.verbose(`GOT ${ticketsRes.status} CONTROL`, controlInfos);
		if (ticketsRes.status.toUpperCase() == ControlValidity.VALID) {
			state.requestState = "2.0.1 - CONTROL_VALID_DB_UPDATE";
			await patchControl(control.controlId, cityId, {
				validity: ControlValidity.VALID,
				agentId: null,
				state: ControlState.NEW,
				tickets: ticketsRes.results,
			});
			state.requestState = "2.0.2 - GET_NEW_CONTROL";
			return getNewControl(cityId, agentId, state);
		}
	}
	/**
	 * 2.0 - Check if a decision is already made for this control thus change CS status
	 */
	event("check last decision history", { controlId: control.controlId });
	state.requestState = "2.1.1 - CHECK DECISION";
	const decision = await getLastDecisionHistory(control.controlId, cityId);

	if (decision) {
		logger.verbose(
			`Control state '${control.state}' mismatch with decision ${decision.status}`,
			controlInfos
		);
		let controlState: ControlState;
		if (decision.status == DecisionStatus.PROCESSING) {
			controlState = ControlState.PROCESSING;
		} else if (decision.status == DecisionStatus.DONE) {
			controlState = ControlState.FINISHED;
		} else {
			// must never happen (getLastDecisionHistory return either PROCESSING or DONE)
		}
		event(`patch control`, { controlState });
		state.requestState = "2.1.2 - CS_UNASSIGN_AGENT";
		await patchControl(control.controlId, cityId, { state: controlState });
		state.requestState = "2.1.3 - GET_NEW_CONTROL";
		return getNewControl(cityId, agentId, state);
	}

	state.requestState = "2.2.1 - GET_CURRENTLY_ASSIGNED_CONTROL";
	const assignedControl = await getAssignedControl(agentId, cityId);
	/**
	 * 2.1 - Must be a state mismatch, so removing last assignation
	 */
	if (assignedControl && assignedControl.controlId !== control.controlId) {
		logger.verbose(`Assigned control state mismatch`, {
			assignedControl: assignedControl.controlId,
			...controlInfos,
		});
		event("unasign agent", { controlId: control.controlId });
		state.requestState = "2.2.2 - DB_UNASSIGN_AGENT";
		await unassignAgent(assignedControl.controlId, cityId, agentId);
	}

	/**
	 * 2.2 - Processing time EXCEEDED
	 */
	if (
		assignedControl &&
		moment(assignedControl.assignedAt).add(
			cityConfig.review.controlReview.processingDelay.duration,
			"seconds"
		) <= moment()
	) {
		event("unasign agent", { controlId: control.controlId });
		state.requestState = "2.2.1 - DB_UNASSIGN_AGENT";
		await unassignAgent(control.controlId, cityId, agentId);
		logger.verbose("Control localy unasigned (Processing time exceeded)", controlInfos);

		state.requestState = "2.2.2 - CS_UNASSIGN_AGENT";
		await patchControl(control.controlId, cityId, {
			agentId: null,
			state: ControlState.WAITING,
		});
		logger.verbose(`Update state to WAITING`, controlInfos);
		state.requestState = "2.2.3 - GET_NEW_CONTROL";
		return getNewControl(cityId, agentId, state);
	}

	/**
	 * 3.0 - Assign agent and return control
	 */
	event(`assign control localy`, { controlId: control.controlId });
	state.requestState = "3.0.1 - DB_ASSING_AGENT";
	await assignAgent(control.controlId, cityId, agentId, control);
	state.requestState = "3.0.2 - GET_CONTROL_DATA";
	event(`get additionnal data`, { controlId: control.controlId });
	const additionalData = await getAdditionalData(control.controlId, cityId);
	return convertControl(
		control,
		cityId,
		agentId,
		cityConfig.review.lapi.validityDelay.duration,
		additionalData,
		// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
		assignedControl?.assignedAt
	);
}

export async function handleControlAssignment(
	cityId: string,
	agentId: string,
	data: { requestState?: string; timeout?: boolean }
): Promise<JsonControl | { message: string; statusCode: number }> {
	try {
		let control: JsonControl | undefined;

		if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "STANDARD") {
			await monit(
				"control.assignation",
				async () => {
					control = await Promise.race([
						getNewControl(cityId, agentId, data),
						new Promise<undefined>((_, reject) =>
							setTimeout(() => reject(new Error("Assignation canceled")), ASSIGNATION_QUEUE_TIMEOUT)
						),
					]).finally(() => (data.timeout = true));
				},
				{ cityId, agentId }
			);

			if (!control) {
				logger.info("No available control", { cityId, agentId });
				return { message: "no control available", statusCode: 204 };
			} else {
				logger.info("Control assigned", { cityId, agentId, controlId: control.controlId });
				sendKafkaMessage("control-assigned", JSON.stringify(control)).catch(console.error);
			}

			return control;
		} else if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "QUALITY") {
			logger.info("QUALITY mode is active, skipping control assignment.");
			const assignedControlResponse = await assignQualityControlToAgent(agentId);

			if (!assignedControlResponse || !assignedControlResponse.control) {
				logger.warn(`No available control for quality review. Agent: ${agentId}`);
				return { message: "No control available for quality review.", statusCode: 204 };
			}

			logger.info(
				`Control successfully assigned to agent ${agentId} in quality mode. Control ID: ${assignedControlResponse.controlId}`
			);

			return assignedControlResponse.control;
		} else {
			throw Error("");
		}
	} catch (err) {
		logger.error(`Error ${data.requestState}`, err, "assignation.error");
		throw new Error("internal server error");
	}
}

export async function hashPlateIfNeeded(
	controlId: string,
	cityId: string,
	jsonbData: ControlAdditionalData & { hashedPlate?: string } = {}
): Promise<ControlAdditionalData & { hashedPlate?: string }> {
	// Vérifie que jsonbData existe et est bien un objet
	if (!jsonbData || typeof jsonbData !== "object") {
		logger.warn(`Invalid jsonbData for control #${controlId}. It must be a valid object.`);
		return jsonbData;
	}

	// Vérifie que la plaque d'immatriculation existe et est une chaîne non vide
	if (jsonbData.plate && typeof jsonbData.plate === "string" && jsonbData.plate.trim().length > 0) {
		// Vérifie si la ville a une configuration et un salt pour le hash des plaques
		if (!citiesConfig.has(cityId) || !citiesConfig.get(cityId).licensePlateSalt) {
			logger.warn(
				`Unable to hash plate for control #${controlId} because there is no configuration or hash salt defined for city #${cityId}`
			);
		} else {
			const salt = citiesConfig.get(cityId).licensePlateSalt;
			// Hache la plaque avec le salt et ajoute-la aux données
			jsonbData.hashedPlate = createPlateHash(jsonbData.plate, salt);
		}
	} else if (jsonbData.plate && typeof jsonbData.plate !== "string") {
		// Si jsonbData.plate existe mais n'est pas une chaîne de caractères valide
		logger.warn(`Invalid plate format for control #${controlId}. It must be a string.`);
	}

	return jsonbData;
}

export async function handleControlUpdate(
	controlId: string,
	cityId: string,
	jsonbData: ControlAdditionalData
): Promise<ControlAdditionalData> {
	try {
		if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "STANDARD") {
			await addAdditionalData(controlId, cityId, jsonbData);
			await addAdditionalDataForQualityCheck(controlId, cityId, jsonbData);
		} else if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "QUALITY") {
			await updateAdditionalDataForQualityCheck(controlId, cityId, jsonbData);
		} else {
			throw new Error("Invalid value for STANDARD_MODE_OR_QUALITY_MODE");
		}
		return jsonbData;
	} catch (err) {
		logger.error(
			`Error during control update for controlId ${controlId} and cityId ${cityId}`,
			err
		);
		throw err;
	}
}
