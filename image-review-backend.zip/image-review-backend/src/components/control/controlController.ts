import { RequestWithJwt } from "@egis-auth/express-security";
import Ajv from "ajv";
import { AxiosResponse } from "axios";
import { Router } from "express";
import logger, { event } from "tsdz-logger";
import { monit } from "tsdz-logger";
import {
	authenticatedMiddleware,
	cityAgentMiddleware,
	PdaJwt,
} from "../../utils/securityMiddleware";
import { ControlState, ControlValidity } from "./controlModel";
import {
	AssignedControl,
	ControlToSkipMetadata,
	DecisionPayloadType,
	ControlResultFps,
	ControlResultNfps,
	ControlAdditionalData,
	DecisionStatus,
	controlAdditionalDataSchema,
} from "./controlModel";
import {
	getAssignedControl,
	getLastDecisionHistory,
	addDecision,
	changeDecisionStatus,
	unassignAgent,
} from "./controlRepository";
import { handleControlAssignment, hashPlateIfNeeded, handleControlUpdate } from "./ControlService";
import { patchControl, minimalRoleResolver, createPlateHash } from "./controlUtil";
import { formatFpsError, sendFps, sendFpsMedia } from "./fpsUtils";
import { formatNfpsError, sendNfps, sendNfpsMedia } from "./nfpsUtils";

const ajv = new Ajv({ allErrors: true });

const router = Router();

// export interface Ticket {
// 	_id: string;
// 	_rev: string;
// 	systemId: string;
// 	licensePlate: string;
// 	profile: TicketProfile;
// 	tariffCode?: string;
// 	startDateTime: string; // Date ISO-8601
// 	endDateTime: string; // Date ISO-8601
// 	paidMinutes: number;
// 	amountPaid: number;
// 	amountCurrency: string;
// 	operatorId: string;
// 	createdAt: string; // Date ISO-8601
// 	licensePlateHash: string;
// 	isSignificant: boolean;
// }

// export interface LapiControl {
// 	_id: string;
// 	_rev: string;
// 	user_id: number;
// 	zone: number;
// 	transit_id: string;
// 	vehicle_id: string;
// 	plate: string;
// 	gen_reliability: number;
// 	char_reliability: [number, number, number, number, number, number, number];
// 	date: string; // ISO-8601
// 	gps_latitude: number;
// 	gps_longitude: number;
// 	gps_heading: number;
// 	gps_pdop: number;
// 	status: LapiControlStatus;
// 	tickets: Ticket[];
// }

router.get(
	"/",
	authenticatedMiddleware("ROLE_AGENT"),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const cityId = req.jwt.codeVille;
		const agentId = req.jwt.matricule;
		const data: { requestState?: string; timeout?: boolean } = {};

		try {
			const result = await handleControlAssignment(cityId, agentId, data);

			if ("message" in result && "statusCode" in result && result.statusCode) {
				return res.status(result.statusCode).json({ message: result.message });
			}

			return res.status(200).json(result);
		} catch (err) {
			res.status(500).json({
				message: "An error occurred while assigning a control.",
			});
		}
	}
);

/**
 * Updates control additional data
 */
router.put(
	"/:controlId",
	authenticatedMiddleware(minimalRoleResolver),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const controlId = req.params.controlId;
		try {
			const control: AssignedControl | undefined = await getAssignedControl(
				req.jwt.matricule,
				req.jwt.codeVille
			);

			if (!control) return res.status(404).send(`No active assigned control.`);

			if (control.controlId !== controlId || req.jwt.matricule !== control.agentId)
				return res
					.status(403)
					.send("Cannot edit control not assigned or assigned to another agent");

			if (Object.keys(req.body).length === 0)
				return res.status(400).send("Payload must not be empty");

			if (!ajv.validate(controlAdditionalDataSchema, req.body)) {
				return res.status(400).json(ajv.errors);
			}

			const jsonbData = await hashPlateIfNeeded(controlId, control.cityId, req.body);

			try {
				const result = await handleControlUpdate(controlId, control.cityId, jsonbData);

				return res.status(200).json(result);
			} catch (err) {
				logger.error("Invalid mode configuration", err);
				return res.status(500).json({
					message: "Invalid configuration for STANDARD_MODE_OR_QUALITY_MODE.",
					status: "Error",
					mode: process.env.STANDARD_MODE_OR_QUALITY_MODE,
				});
			}
		} catch (err) {
			logger.error("control additional data update error", err);
			res.status(500).json({
				code: 500,
				error: err,
			});
		}
	}
);

/**
 * Emits FPS
 * Uses the following workflow :
 *  - IR Frontend builds FPS payload
 *  - IR Frontend send payload to WS-Control
 *  - WS-Control forwards FPS to WS-FPS-Dispatcher
 *  - WS-FPS-Dispatcher forwards FPS to FPS processing server
 *  - IF SUCCESS
 *    - then response chains back to WS control
 *    - WS Control closes control
 *    - WS Control saves KPI about FPS emission
 *    - WS Control send back original success response to IR Frontend
 *  - IF ERROR
 *    - THEN response chains back to WS control
 *    - WS Control DO NOT CLOSE control
 *    - WS Control DO NOT SAVE KPI about FPS emission
 *    - WS Control log failed action ?
 *    - WS Control send back original error to IR Frontend
 */
router.post(
	"/:controlId/emit-fps",
	authenticatedMiddleware(minimalRoleResolver),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const controlId = req.params.controlId;
		const agentId = req.jwt.matricule;
		const cityId = req.jwt.codeVille;
		const infos = { controlId, agentId, cityId };
		await monit(
			"control.decision.fps",
			// do not put buisness logic there...
			async (): Promise<void> => {
				try {
					const control: AssignedControl | undefined = await getAssignedControl(
						req.jwt.matricule,
						cityId
					);
					// Does the agent have an assigned control?
					if (!control) {
						res.status(404).send(`No active assigned control.`);
						return;
					}

					// Does assigned control match the specified control in URL?
					if (control.controlId !== controlId || req.jwt.matricule !== control.agentId) {
						res.status(403).send("Cannot edit control not assigned or assigned to another agent");
						return;
					}

					// Is there already a decision for this control?
					const decision = await getLastDecisionHistory(controlId, cityId);
					if (decision) {
						res.status(409).send(`A decision was already emitted for control #${controlId}`);
						return;
					}

					const { fpsData, mediasUrl } = req.body as ControlResultFps;

					if (!fpsData || !mediasUrl) {
						res
							.status(400)
							.send("Invalid form fields. Fields 'fpsData' or 'mediasUrl' are missing.");
						return;
					}

					const agentJwt = req.headers["x-bearer-token"] as string;

					const resAddDecision = await addDecision({
						agentId: control.agentId,
						assignedAt: control.assignedAt,
						cityId: control.cityId,
						controlId: control.controlId,
						createdAt: control.controlData.controlDate,
						decision: DecisionPayloadType.FPS,
						lapiId: control.controlData.userId,
						vehicleCategory: fpsData.vehicle.vehiculeCategory || fpsData.vehicle.vehicleCategory,
						payload: {
							fpsData,
							mediasUrl,
						},
						status: DecisionStatus.PROCESSING,
					});

					event(`Unassiging agent`);
					await unassignAgent(control.controlId, cityId, agentId).catch(() =>
						logger.warn(
							`Tried to unassign agent #${agentId} from non-existing control #${control.controlId}.`
						)
					);

					event("patch control", { state: ControlState.PROCESSING });
					await patchControl(control.controlId, control.cityId, {
						state: ControlState.PROCESSING,
						agentId: control.agentId,
						vehicleCategory: fpsData.vehicle.vehiculeCategory || fpsData.vehicle.vehicleCategory,
						licensePlate: fpsData.licensePlate.plate,
						plateCountry: fpsData.licensePlate.plateCountry,
						vehicleModel: fpsData.vehicle.model,
						vehicleBrand: fpsData.vehicle.brand,
					});

					// Send back aknowledgement for FPS processing
					res.status(200).json({});

					let fpsRes: AxiosResponse | undefined;

					event(`Sending FPS`);
					fpsRes = await sendFps(
						fpsData,
						control.cityId,
						control.controlId,
						req.headers["x-bearer-token"] as string,
						new Date(control.controlData.expiresAt),
						{
							latitude: control.controlData.latitude,
							longitude: control.controlData.longitude,
							accuracy: control.controlData.accuracy,
						}
					);

					if (fpsRes.status >= 400) {
						const formattedError = formatFpsError(fpsRes, fpsData);
						logger.info(
							`Sending FPS #${fpsData.fineLegalId} for control #${control.controlId} returned ${fpsRes.status} code. Saving message into database and placing it back in queue`,
							formattedError
						);
						event(`Updating control`, { state: ControlState.WAITING });
						await patchControl(control.controlId, control.cityId, {
							metadata: JSON.stringify(formattedError),
							state: ControlState.WAITING,
							agentId: null,
						});
						event(`Updating decision status`, { status: DecisionStatus.INVALID });
						await changeDecisionStatus(control.controlId, control.cityId, DecisionStatus.INVALID);
						return;
					}

					// At this point we assume that the fps was sent correctly
					logger.verbose(`Saved FPS #${fpsData.fineLegalId} for control #${control.controlId}`);
					logger.debug(
						`FPS Content #${fpsData.fineLegalId} for control #${control.controlId}`,
						fpsRes.data
					);

					const metadata = {
						decision: {
							type: DecisionPayloadType.FPS,
							id: fpsData.fineLegalId,
							treatmentDate: resAddDecision.submittedAt,
						},
					};

					await patchControl(control.controlId, control.cityId, {
						metadata: JSON.stringify(metadata),
					});

					for (const media of mediasUrl) {
						try {
							event(`Sending FPS media`, { photo: media });
							await sendFpsMedia(control.cityId, fpsData, media, fpsRes.data.fineId, agentJwt);
						} catch (err) {
							logger.error(
								`Unable to send FPS media #${fpsData.fineLegalId}/${media} for control #${control.controlId}`,
								err
							);
						}
					}

					// Update LAPI control status
					event(`patch control`, { state: ControlState.FINISHED });
					await patchControl(control.controlId, control.cityId, { state: ControlState.FINISHED });

					event(`Updating decision status`, { status: DecisionStatus.DONE });
					await changeDecisionStatus(control.controlId, control.cityId, DecisionStatus.DONE, true);
					return;
				} catch (err) {
					logger.error("fps emission error", err);
					if (!res.headersSent) {
						res.status(500).json({
							code: 500,
							error: err,
						});
					}
				}
			},
			infos
		);
	}
);

/**
 * Emits NFPS
 * Uses the following workflow :
 *  - IR Frontend builds NFPS payload
 *  - IR Frontend send payload to WS-Control
 *  - WS-Control forwards NFPS to WS-NFPS-Dispatcher
 *  - WS-NFPS-Dispatcher forwards NFPS to NFPS processing server
 *  - IF SUCCESS
 *    - then response chains back to WS control
 *    - WS Control closes control
 *    - WS Control saves KPI about NFPS emission
 *    - WS Control send back original success response to IR Frontend
 *  - IF ERROR
 *    - THEN response chains back to WS control
 *    - WS Control DO NOT CLOSE control
 *    - WS Control DO NOT SAVE KPI about NFPS emission
 *    - WS Control log failed action ?
 *    - WS Control send back original error to IR Frontend
 */
router.post(
	"/:controlId/emit-nfps",
	authenticatedMiddleware(minimalRoleResolver),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const controlId = req.params.controlId;
		const agentId = req.jwt.matricule;
		const cityId = req.jwt.codeVille;

		await monit("control.decision.nfps", async (): Promise<void> => {
			try {
				const control: AssignedControl | undefined = await getAssignedControl(
					req.jwt.matricule,
					cityId
				);
				// Does the agent have an assigned control?
				if (!control) {
					res.status(404).send(`No active assigned control.`);
					return;
				}

				// Does assigned control match the specified control in URL?
				if (control.controlId !== controlId || req.jwt.matricule !== control.agentId) {
					res.status(403).send("Cannot edit control not assigned or assigned to another agent");
					return;
				}

				// Is there already a decision for this control?
				const decision = await getLastDecisionHistory(controlId, cityId);
				if (decision) {
					res.status(409).send(`A decision was already emitted for control #${controlId}`);
					return;
				}

				const { nfpsData, mediasUrl } = req.body as ControlResultNfps;

				if (!nfpsData || !mediasUrl) {
					res
						.status(400)
						.send("Invalid form fields. Fields 'nfpsData' or 'mediasUrl' are missing.");
					return;
				}

				const agentJwt = req.headers["x-bearer-token"] as string;

				const resAddDecision = await addDecision({
					agentId: control.agentId,
					assignedAt: control.assignedAt,
					cityId: control.cityId,
					controlId: control.controlId,
					createdAt: control.controlData.controlDate,
					decision: DecisionPayloadType.NFPS,
					lapiId: control.controlData.userId,
					vehicleCategory: nfpsData.params.vehicleCategory,
					payload: {
						nfpsData,
						mediasUrl,
					},
					status: DecisionStatus.PROCESSING,
				});

				event(`Unassiging agent`);
				await unassignAgent(control.controlId, cityId, agentId).catch(() =>
					logger.warn(
						`Tried to unassign agent #${agentId} from non-existing control #${control.controlId}.`
					)
				);
				event(`Updating control`, { state: ControlState.PROCESSING });
				await patchControl(control.controlId, control.cityId, {
					state: ControlState.PROCESSING,
					agentId: control.agentId,
					vehicleCategory: nfpsData.params.vehicleCategory,
					licensePlate: nfpsData.params.licensePlate,
					plateCountry: nfpsData.params.plateCountry,
					vehicleModel: nfpsData.params.vehicleModel,
					vehicleBrand: nfpsData.params.vehicleBrand,
				});

				// Send back aknowledgement for FPS processing
				res.status(200).json({});

				let nfpsRes: AxiosResponse | undefined;

				event(`Sending NFPS`);
				nfpsRes = await sendNfps(
					nfpsData,
					control.cityId,
					control.controlId,
					req.headers["x-bearer-token"] as string,
					new Date(control.controlData.expiresAt)
				);

				if (nfpsRes.status >= 400) {
					const formattedError = formatNfpsError(nfpsRes, nfpsData);
					logger.verbose(
						`Sending NFPS #${nfpsData.id} for control #${control.controlId} returned ${nfpsRes.status} code. Saving message into database and placing it back in queue`,
						formattedError
					);
					event(`Updating control`, { state: ControlState.WAITING });
					await patchControl(control.controlId, control.cityId, {
						metadata: JSON.stringify(formattedError),
						state: ControlState.WAITING,
						agentId: null,
					});
					event(`Updating decision status`, { status: DecisionStatus.INVALID });
					await changeDecisionStatus(control.controlId, control.cityId, DecisionStatus.INVALID);
					return;
				}

				// At this point we assume that the fps was sent correctly
				logger.verbose(`Saved NFPS #${nfpsRes.data.id} for control #${control.controlId}`);
				logger.debug(
					`NFPS Content #${nfpsRes.data.id} for control #${control.controlId}`,
					nfpsRes.data
				);

				const metadata = {
					decision: {
						type: DecisionPayloadType.NFPS,
						id: nfpsRes.data.id,
						payload: { exemptionReason: nfpsData.params.exemptionReason },
						treatmentDate: resAddDecision.submittedAt,
					},
				};

				await patchControl(control.controlId, control.cityId, {
					metadata: JSON.stringify(metadata),
				});

				for (const media of mediasUrl) {
					try {
						event(`Sending NFPS media`, { photo: media });
						await sendNfpsMedia(control.cityId, nfpsData, media, nfpsRes.data.id, agentJwt);
					} catch (err) {
						logger.error(
							`Unable to send NFPS media #${nfpsData.id}/${media} for control #${control.controlId}`,
							err
						);
					}
				}

				// Update LAPI control status
				event(`Updating control`, { state: ControlState.FINISHED });
				await patchControl(control.controlId, control.cityId, {
					state: ControlState.FINISHED,
				});

				event(`Updating decision status`, { state: DecisionStatus.DONE });
				await changeDecisionStatus(control.controlId, control.cityId, DecisionStatus.DONE, true);
				return;
			} catch (err) {
				logger.error("nfps emission error", err);
				if (!res.headersSent) {
					res.status(500).json({
						code: 500,
						error: err,
					});
				}
			}
		});
	}
);

/**
 * skip control
 * Uses the following workflow :
 *  - IR Frontend builds SKIP payload
 *  - IR Frontend send payload to WS-Control
 *  - then response chains back to WS control
 */
router.post(
	"/:controlId/skip",
	authenticatedMiddleware(minimalRoleResolver),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const controlId = req.params.controlId;
		const agentId = req.jwt.matricule;
		const cityId = req.jwt.codeVille;

		await monit("control.decision.nfps", async (): Promise<void> => {
			try {
				const control: AssignedControl | undefined = await getAssignedControl(
					req.jwt.matricule,
					cityId
				);
				// Does the agent have an assigned control?
				if (!control) {
					res.status(404).send(`No active assigned control.`);
					return;
				}

				// Does assigned control match the specified control in URL?
				if (control.controlId !== controlId || req.jwt.matricule !== control.agentId) {
					res.status(403).send("Cannot edit control not assigned or assigned to another agent");
					return;
				}

				// Is there already a decision for this control ?
				const decision = await getLastDecisionHistory(controlId, cityId);
				if (decision) {
					res.status(409).send(`A decision was already emitted for control #${controlId}`);
					return;
				}

				const { ...metadatas } = req.body as ControlToSkipMetadata;

				event(`Unassiging agent`);
				await unassignAgent(control.controlId, cityId, agentId).catch(() =>
					logger.warn(
						`Tried to unassign agent #${agentId} from non-existing control #${control.controlId}.`
					)
				);

				// Update LAPI control status
				event(`Updating control`, { state: ControlState.PROCESSING });
				await patchControl(control.controlId, control.cityId, {
					// note : control in control-service should be immutable, but anyway...
					state: ControlState.NEW,
					agentId: null,
					tickets: metadatas.tickets,
					validity: metadatas.validity as unknown as ControlValidity,
					vehicleCategory: metadatas.vehicleCategory,
					licensePlate: metadatas.licensePlate.plate,
					plateCountry: metadatas.licensePlate.plateCountry,
					vehicleModel: metadatas.vehicleModel,
					vehicleBrand: metadatas.vehicleBrand,
					// look there, should we update the zone in statistics
					longitude: metadatas.longitude,
					latitude: metadatas.latitude,
				});

				// Send back aknowledgement for FPS processing
				res.status(200).json({});

				return;
			} catch (err) {
				logger.error("skip emission error", err);
				if (!res.headersSent) {
					res.status(500).json({
						code: 500,
						error: err,
					});
				}
			}
		});
	}
);

export default router;
