import { Ticket } from "@egis-smartcity/parking/dist/ticket/swagger";
import { FpsCountry } from "@egis-smartcity/parking";
import { Validity } from "@egis-smartcity/parking/dist/controlReview/swagger";
import { Fps, Nfps } from "@egis-smartcity/parking";
import { LapiControl } from "@egis-smartcity/parking/dist/controlReview/swagger";

export interface PaginatedResult<T> {
	size: number;
	limit: number;
	results: T[];
}

export enum ControlType {
	PDA = "PDA",
	LAPI = "LAPI",
}

export enum ControlValidity {
	VALID = "VALID",
	INVALID = "INVALID",
	PENDING = "PENDING",
}

// export enum ControlProgress {
// 	INCOMPLETE = "INCOMPLETE",
// 	COMPLETE = "COMPLETE",
// }

export enum ControlProgress {
	INCOMPLETE = "INCOMPLETE",
	COMPLETE = "COMPLETE",
	EXPIRED = "EXPIRED",
	PROCESSED = "PROCESSED",
}

export enum ControlState {
	NEW = "NEW",
	WAITING = "WAITING",
	VERIFY = "VERIFY",
	ASSIGNED = "ASSIGNED",
	WORKING = "WORKING",
	EXPIRED = "EXPIRED",
	PROCESSING = "PROCESSING",
	FINISHED = "FINISHED",
}

export enum ControlPriority {
	LOW = "LOW",
	HIGH = "HIGH",
}

export interface ResponseControl {
	controlId: string;
	controlDate: string;
	licensePlate: string;
	agentId: string | null;
	userId: string;
	terminalId: string;
	transitId: string;
	latitude: number;
	longitude: number;
	expiresAt: string;
	priority: ControlPriority;
	validity: ControlValidity;
	progress: ControlProgress;
	state: ControlState;
	tickets?: Array<Ticket>;
	type: ControlType;
	genReliability?: number;
	charReliability?: Array<number>;
	gpsHeading: number;
	gpsPdop?: number;
	accuracy: number;
	platePicture?: string;
	contextPictures?: Array<string>;
	metadata?: string;
	vehicleCategory?: string;
	vehicleBrand?: string;
	vehicleModel?: string;
	plateCountry?: string;
}

export interface UpdateControlPayload {
	progress?: ControlProgress;
	state?: ControlState;
	validity?: ControlValidity;
	tickets?: Array<Ticket>;
	priority?: ControlPriority;
	agentId?: string;
	metadata?: string;
	vehicleCategory?: string;
	vehicleBrand?: string;
	vehicleModel?: string;
	plateCountry?: string;
	licensePlate?: string;
	longitude?: number;
	latitude?: number;
}

export interface DispatcherTicketRes {
	results: Ticket[];
	status: ControlValidity;
	scanDate: string;
	parameters: {
		latitude: string;
		longitude: string;
		scandate: string;
		transitid: string;
		locationcode: string;
		tariffcode: string;
		licensePlate: string;
	};
}

export interface ControlToSkipMetadata {
	validity?: Validity;
	tickets?: Ticket[];
	licensePlate?: {
		plate: string;
		plateCountry?: FpsCountry;
	};
	vehicleCategory?: string;
	vehicleModel?: string;
	vehicleBrand?: string;
	latitude?: number;
	longitude?: number;
}

export interface AdditionalDataRecord<
	IdType = string,
	ValueType = string,
	NullableValue extends undefined | true = undefined
> {
	id: IdType;
	label: string;
	value: NullableValue extends boolean ? ValueType | null : ValueType;
}

export interface LonLat {
	lon: number;
	lat: number;
}

export enum DecisionPayloadType {
	FPS = "FPS",
	NFPS = "NFPS",
}

export type DecisionPayload = ControlResultFps | ControlResultNfps;

export interface CouchDbError {
	error: string;
	reason: string;
}
export interface ControlResultFps {
	fpsData: Fps;
	mediasUrl: string[];
}

export interface ControlResultNfps {
	nfpsData: Nfps;
	mediasUrl: string[];
}

export interface ControlAdditionalData {
	plate?: string;
	country?: AdditionalDataRecord;
	vehicleCategory?: Omit<AdditionalDataRecord<string, string, true>, "id">;
	brand?: AdditionalDataRecord | null;
	model?: AdditionalDataRecord | null;
	position?: LonLat;
	zone?: Omit<AdditionalDataRecord, "id">;
	sector?: Omit<AdditionalDataRecord, "id">;
	address?: string;
	postalCode?: string;
	city?: string;
	mediasUrl?: string[];
}

export type DebugInsertLapiControl = Omit<LapiControl, "status" | "progress"> & {
	status: ControlValidity;
	progress: ControlProgress;
};

export interface JsonControl {
	controlId: string;
	control: DebugInsertLapiControl;
	additionalData: ControlAdditionalData;
	lapiId: string;
	cityId: string;
	status: ControlState;
	agentId?: string;
	createdAt: string;
	expiresAt: string;
	assignedAt?: string;
	doneAt: string;
	message?: ErrorMessage;
	decisionPayload?: DecisionPayload;
}

export type ErrorMessage = {
	code: string;
	description: string;
	reason: { [key: string]: string | number };
};

export interface DbAssignedControl {
	control_id: string;
	city_id: string;
	agent_id: string;
	assigned_at: string;
	done_at?: string;
	control_data: ResponseControl;
}

export interface AssignedControl {
	controlId: string;
	cityId: string;
	agentId: string;
	assignedAt: string;
	vehicleCategory?: string;
	doneAt?: string;
	controlData: ResponseControl;
}

export enum DecisionStatus {
	// Decision is under process
	"PROCESSING" = "PROCESSING",

	// Decision was sucessfully emited
	"DONE" = "DONE",

	// Decision was invalid
	"INVALID" = "INVALID",

	// Decision failed to send
	"FAILED" = "FAILED",
}

export interface DbControlDecision {
	control_id: string;
	city_id: string;
	lapi_id: string;
	agent_id: string;
	decision: DecisionPayloadType;
	payload: DecisionPayload;
	status: DecisionStatus;
	created_at: string; // Date, when the control was created.
	assigned_at: string; // Date, when the agent was assigned the control.
	submitted_at: string; // Date, when the decision was submitted.
	done_at?: string; // Date, when the decision was fully processed.
}

export interface ControlDecision {
	controlId: string;
	cityId: string;
	lapiId: string;
	agentId: string;
	vehicleCategory?: string;
	decision: DecisionPayloadType;
	payload: DecisionPayload;
	status: DecisionStatus;
	createdAt: string; // Date, when the control was created.
	assignedAt: string; // Date, when the agent was assigned the control.
	submittedAt: string; // Date, when the decision was submitted.
	doneAt?: string; // Date, when the decision was fully processed.
}

export enum LapiControlStatus {
	VALID = "VALID",
	INVALID = "INVALID",
}

/** @todo: Complete enum */
export enum TicketProfile {
	VIS = "VIS",
	RES = "RES",
	FPS = "FPS",
	PMR = "PMR",
	PRO_M = "PRO-M",
	PRO_S = "PRO-S",
	PRO_P = "PRO-P",
	VP = "VP",
}

// export interface Ticket {
// 	_id: string;
// 	_rev: string;
// 	systemId: string;
// 	licensePlate: string;
// 	profile: TicketProfile;
// 	tariffCode?: string;
// 	startDateTime: string; // Date ISO-8601
// 	endDateTime: string; // Date ISO-8601
// 	paidMinutes: number;
// 	amountPaid: number;
// 	amountCurrency: string;
// 	operatorId: string;
// 	createdAt: string; // Date ISO-8601
// 	licensePlateHash: string;
// 	isSignificant: boolean;
// }



// export interface LapiControl {
// 	_id: string;
// 	_rev: string;
// 	user_id: number;
// 	zone: number;
// 	transit_id: string;
// 	vehicle_id: string;
// 	plate: string;
// 	gen_reliability: number;
// 	char_reliability: [number, number, number, number, number, number, number];
// 	date: string; // ISO-8601
// 	gps_latitude: number;
// 	gps_longitude: number;
// 	gps_heading: number;
// 	gps_pdop: number;
// 	status: LapiControlStatus;
// 	tickets: Ticket[];
// }


const makeAdditionalDataRecordSchema = (
	idType: "string" | "number" = "string",
	valueType: "string" | "number" = "string",
	omitId: boolean = false,
	nullableValue: boolean = false
) => {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	const properties: Record<string, any> = {
		label: {
			type: "string",
		},
		value:
			nullableValue === true
				? { anyOf: [{ type: valueType }, { type: "null" }] }
				: { type: valueType },
	};

	if (!omitId) {
		properties.id = {
			type: idType,
		};
	}

	return {
		type: "object",
		additionalProperties: false,
		require: ["id", "label", "value"].filter((e) => !(e === "id" && omitId)),
		properties,
	};
};

export const controlAdditionalDataSchema = {
	type: "object",
	additionalProperties: false,
	properties: {
		plate: {
			type: "string",
		},
		country: makeAdditionalDataRecordSchema(),
		vehicleType: makeAdditionalDataRecordSchema("string", "string", true, true),
		brand: { anyOf: [makeAdditionalDataRecordSchema(), { type: "null" }] },
		model: {
			anyOf: [makeAdditionalDataRecordSchema(), { type: "null" }],
		},
		position: {
			type: "object",
			required: ["lon", "lat"],
			properties: {
				lon: {
					type: "number",
				},
				lat: {
					type: "number",
				},
			},
		},
		zone: makeAdditionalDataRecordSchema("string", "string", true),
		sector: makeAdditionalDataRecordSchema("string", "string", true),
		address: {
			type: "string",
		},
		streetNumber: {
			type: "string",
		},
		postalCode: {
			type: "string",
		},
		city: {
			type: "string",
		},
		mediasUrl: {
			type: "array",
			items: {
				type: "string",
			},
		},
	},
};
