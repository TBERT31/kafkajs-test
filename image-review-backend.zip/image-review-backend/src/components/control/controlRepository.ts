import sql from "sql-template-strings";

import pool from "../../utils/db";
import logger from "../../utils/logger";

import { 
	AssignedControl,
	ResponseControl,
	ControlDecision,
	ControlAdditionalData,
	DbAssignedControl,
	DbControlDecision,
	DecisionStatus,
} from "./controlModel";

/*************************************************************/
/********************* STANDARD MODE *************************/
/*************************************************************/

function dbAssignedControlToJson(assignedControl: DbAssignedControl): AssignedControl {
	return {
		controlId: assignedControl.control_id,
		cityId: assignedControl.city_id,
		agentId: assignedControl.agent_id,
		assignedAt: assignedControl.assigned_at,
		doneAt: assignedControl.done_at,
		controlData: assignedControl.control_data,
	};
}

function dbControlDecisionToJson(decision: DbControlDecision): ControlDecision {
	return {
		controlId: decision.control_id,
		cityId: decision.city_id,
		agentId: decision.agent_id,
		lapiId: decision.lapi_id,
		decision: decision.decision,
		payload: decision.payload,
		status: decision.status,
		createdAt: decision.created_at,
		assignedAt: decision.assigned_at,
		submittedAt: decision.submitted_at,
		doneAt: decision.done_at,
	};
}

export function getAssignedControl(agentId: string, cityId: string) {
	return new Promise<AssignedControl | undefined>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          SELECT *
        FROM "control".assigned_controls
        WHERE
          agent_id = ${agentId} AND
          city_id = ${cityId} AND
          done_at IS NULL
        ;`
			);
			if (qryResult.rowCount === 0) return resolve(undefined);
			return resolve(dbAssignedControlToJson(qryResult.rows[0]));
		} catch (err) {
			logger.error(
				`[ASSIGNED-GET-CONTROL][cityId:${cityId}][agentId:${agentId}] - Error patch control`,
				err
			);
			reject(err);
		}
	});
}

/**
 * Assigns an agent to a control in Standard mode
 * @param controlId Control ID
 * @param cityId CityId
 * @param agentId Agent's ID
 */
export function assignAgent(
	controlId: string,
	cityId: string,
	agentId: string,
	control: ResponseControl
) {
	return new Promise<void>(async (resolve, reject) => {
		try {
			await pool.query(
				sql`
          INSERT INTO control.assigned_controls
          VALUES (${controlId}, ${cityId}, ${agentId}, NOW(), NULL, ${control})
          ON CONFLICT DO NOTHING
          RETURNING *
        ;`
			);
			return resolve();
		} catch (err) {
			logger.error(
				`[ASSIGNED-GET-CONTROL][cityId:${cityId}][agentId:${agentId}][controlId:${controlId}] - Error assign agent`,
				err
			);
			reject(err);
		}
	});
}

/**
 * Unassigns agent from a control, resulting as a failed control
 * @param controlId Control ID
 * @param cityId CityId
 * @param agentId Agent's ID
 */
export function unassignAgent(controlId: string, cityId: string, agentId: string) {
	return new Promise<void>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          DELETE FROM control.assigned_controls
          WHERE
            control_id=${controlId} AND
            city_id=${cityId} AND
            agent_id=${agentId}
          RETURNING *
        ;`
			);
			if (qryResult.rowCount === 0) return reject(new Error("Control not found"));
			return resolve();
		} catch (err) {
			logger.error(
				`[ASSIGNED-UNASSIGN-AGENT][cityId:${cityId}][agentId:${agentId}][controlId:${controlId}] - Error unassign agent`,
				err
			);
			reject(err);
		}
	});
}

export function addAdditionalData(controlId: string, cityId: string, data: ControlAdditionalData) {
	return new Promise<ControlAdditionalData>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          INSERT INTO control.additional_data
          (control_id, city_id, additional_data)
          VALUES(${controlId}, ${cityId}, ${data})
          ON CONFLICT (control_id)
          DO
            UPDATE SET additional_data = ${data}
        ;`
			);
			if (qryResult.rowCount === 0) return reject(new Error("Control not found"));
			return resolve(data);
		} catch (err) {
			logger.error(
				`[ASSIGNED-ADDITIONALDATA-CONTROL][cityId:${cityId}][controlId:${controlId}] - Error add additional data`,
				err
			);
			reject(err);
		}
	});
}

export function getAdditionalData(controlId: string, cityId: string) {
	return new Promise<ControlAdditionalData | undefined>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          SELECT additional_data FROM control.additional_data
          WHERE
            control_id=${controlId} AND
            city_id=${cityId}
        ;`
			);
			if (qryResult.rowCount === 0) return resolve(undefined);
			return resolve(qryResult.rows[0].additional_data);
		} catch (err) {
			logger.error(
				`[ASSIGNED-ADDITIONALDATA-CONTROL][cityId:${cityId}][controlId:${controlId}] - Error get additional data`,
				err
			);
			reject(err);
		}
	});
}

export function deleteAdditionalData(controlId: string, cityId: string) {
	return new Promise<ControlAdditionalData>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          DELETE FROM control.additional_data
          WHERE
            control_id=${controlId} AND
            city_id=${cityId}
          RETURNING *
        ;`
			);
			if (qryResult.rowCount === 0) return reject(new Error("Control not found"));
			return resolve(qryResult.rows[0].additional_data);
		} catch (err) {
			logger.error(err);
			reject(err);
		}
	});
}

export function addDecision(decision: Omit<ControlDecision, "submittedAt">) {
	return new Promise<ControlDecision | undefined>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          INSERT INTO "control".decisions_history
          (
            id,
            control_id,
            city_id,
            lapi_id,
            agent_id,
            decision,
            payload,
            status,
            vehicle_category,
            created_at,
            assigned_at,
            submitted_at,
            done_at
          )
          VALUES (
            DEFAULT,
            ${decision.controlId},
            ${decision.cityId},
            ${decision.lapiId},
            ${decision.agentId},
            ${decision.decision},
            ${decision.payload},
            ${decision.status},
            ${decision.vehicleCategory || null},
            ${decision.createdAt},
            ${decision.assignedAt},
            NOW(),
            NULL
          )
          RETURNING *
        `
			);
			if (qryResult.rowCount === 0) return resolve(undefined);
			return resolve(dbControlDecisionToJson(qryResult.rows[0]));
		} catch (err) {
			logger.error(err);
			reject(err);
		}
	});
}

export function getLastDecisionHistory(controlId: string, cityId: string) {
	return new Promise<ControlDecision | undefined>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          SELECT *
          FROM control.decisions_history
          WHERE
            control_id=${controlId} AND
            city_id=${cityId} AND
            (status = 'DONE' OR status = 'PROCESSING')
          ;
        `
			);
			if (qryResult.rowCount === 0) return resolve(undefined);
			return resolve(dbControlDecisionToJson(qryResult.rows[0]));
		} catch (err) {
			logger.error(
				`[ASSIGN-PATCH-CONTROL][cityId:${cityId}][controlId:${controlId}] - Error patch control`,
				err
			);
			reject(err);
		}
	});
}

export async function changeDecisionStatus(
	controlId: string,
	cityId: string,
	status: DecisionStatus,
	done: boolean = false
) {
	// Here control statuses FAILED and DONE musn't be mutated.
	const qryResult = await pool.query(
		sql`
          UPDATE "control".decisions_history
          SET status = ${status}, done_at = ${done ? "NOW()" : null}
          WHERE
            control_id = ${controlId} AND
            city_id = ${cityId} AND
            status <> 'FAILED' AND
            status <> 'DONE'
          RETURNING *
        `
	);
	return qryResult.rowCount === 0 ? undefined : dbControlDecisionToJson(qryResult.rows[0]);
}

/*************************************************************/
/********************* QUALITY MODE *************************/
/*************************************************************/

/**
 * Create a control in quality_check schema.
 * @param controlId Control ID
 * @param cityId CityId
 * @param agentIdImageReview Agent's ID for Quality Review
 * @param control Control data (ResponseControl)
 */
export function createControlForQualityCheck(
	controlId: string,
	cityId: string,
	agentIdImageReview: string,
	control: ResponseControl
) {
	return new Promise<void>(async (resolve, reject) => {
		try {
			await pool.query(
				sql`
          INSERT INTO quality_check.qc_assigned_controls (
            control_id,
            city_id,
            agent_id,
            agent_id_in_image_review,
            assigned_at,
            assigned_at_in_image_review,
            done_at,
            done_at_in_image_review,
            control_data
          )
          VALUES (
            ${controlId},
            ${cityId},
            NULL,  -- agent_id
            ${agentIdImageReview}, -- agent_id_in_image_review
            NULL,  	-- assigned_at
            NOW(),  -- assigned_at_in_image_review
            NULL,  -- done_at
            NULL,  -- done_at_in_image_review
            ${control}  -- control_data (JSON)
          )
          ON CONFLICT DO NOTHING
          RETURNING *
        ;`
			);
			return resolve();
		} catch (err) {
			logger.error(
				`[ASSIGNED-GET-CONTROL-QUALITY][cityId:${cityId}][agentIdImageReview:${agentIdImageReview}][controlId:${controlId}] - Error assigning quality agent`,
				err
			);
			reject(err);
		}
	});
}

export async function assignQualityControlToAgent(agentId: string) {
	try {
		const client = await pool.connect();
		try {
			const qryResult = await client.query(
				// eslint-disable-next-line no-secrets/no-secrets
				sql`
				SELECT control_id, city_id, agent_id_in_image_review, control_data
				FROM "quality_check".qc_assigned_controls
				WHERE agent_id IS NULL
				LIMIT 1
				FOR UPDATE; -- Lock the row to prevent other transactions from accessing it
				`
			);

			if (qryResult.rowCount === 0) {
				logger.info("No unassigned control available in quality mode");
				return { message: "no control available for quality review" };
			}

			const foundControl = qryResult.rows[0];
			await client.query(
				sql`
				UPDATE "quality_check".qc_assigned_controls
				SET agent_id = ${agentId}, assigned_at = NOW()
				WHERE control_id = ${foundControl.control_id};
				`
			);

			await client.query('COMMIT');

			logger.info("Control assigned in quality mode", { agentId, controlId: foundControl.control_id });

			return {
				controlId: foundControl.control_id,
				cityId: foundControl.city_id,
				agentId: agentId,
				assignedAt: new Date().toISOString(),
				control: foundControl.control_data,
			};
		} catch (err) {
			await client.query('ROLLBACK');
			logger.error("Error assigning control in quality mode", err);
			throw err;
		} finally {
			client.release();
		}

	} catch (err) {
		logger.error("Database error during control assignment", err);
		throw new Error("Database error during control assignment");
	}
}

export function addAdditionalDataForQualityCheck(controlId: string, cityId: string, dataInImageReview: ControlAdditionalData) {
	return new Promise<ControlAdditionalData>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          INSERT INTO quality_check.qc_additional_data
          (control_id, city_id, created_at, additional_data_in_image_review)
          VALUES(${controlId}, ${cityId}, NOW(), ${dataInImageReview})
          ON CONFLICT (control_id)
          DO
            UPDATE SET qc_additional_data = ${dataInImageReview}
        ;`
			);
			if (qryResult.rowCount === 0) return reject(new Error("Control not found"));
			return resolve(dataInImageReview);
		} catch (err) {
			logger.error(
				`[ASSIGNED-ADDITIONALDATA-CONTROL-FOR-QUALITY-CHECK][cityId:${cityId}][controlId:${controlId}] - Error add additional data for quality check`,
				err
			);
			reject(err);
		}
	});
}

export function updateAdditionalDataForQualityCheck(
	controlId: string,
	cityId: string,
	jsonbData: ControlAdditionalData
): Promise<any> {
	return new Promise(async (resolve, reject) => {
		try {
			const qryResult = await pool.query(
				sql`
          UPDATE quality_check.qc_additional_data
          SET additional_data_in_image_review = ${jsonbData}, updated_at = NOW()
          WHERE control_id = ${controlId} AND city_id = ${cityId}
          RETURNING *;
        `
			);

			if (qryResult.rowCount === 0) {
				return reject(new Error("No matching control found for update."));
			}

			resolve(qryResult.rows[0]);
		} catch (err) {
			logger.error(
				`[UPDATE-ADDITIONALDATA-FOR-QUALITY][controlId:${controlId}][cityId:${cityId}] - Error updating additional data`,
				err
			);
			reject(err);
		}
	});
}
