import axios, { AxiosError } from "axios";
import { createHash } from "crypto";
import QueryString from "qs";
import logger from "tsdz-logger";
import { CityConfig } from "../../utils/citiesConfigs";
import getApiToken from "../../utils/citiesCredentials";
import { CONTROL_SERVICE_ENDPOINT } from "../../utils/secrets";
import { 
	ControlState, 
	ResponseControl, 
	UpdateControlPayload, 
	ControlProgress 
} from "./controlModel";
import { and, or } from "@egis-auth/authorization";

export const minimalRoleResolver = and("ROLE_AGENT", "ROLE_PDA", or("ROLE_LAPI", "ROLE_LAPI_CONSULT"));

export async function getAndAssignControl(
	agentId: string,
	cityId: string,
	cityConfig: Partial<CityConfig>,
	currentDate: Date = new Date()
) {
	const queryString = QueryString.stringify({
		agentid: agentId,
		assign: true,
		state: ControlState.WAITING,
		progress: ControlProgress.COMPLETE,
		//userid: (cityConfig.review.lapi.lapiFilter || []).join(","),
		terminalid: (cityConfig.review.lapi.lapiFilter || []).join(","),
		maxdate: cityConfig.review.controlReview.retentionDelay
			? new Date(currentDate.getTime() - cityConfig.review.controlReview.retentionDelay * 1000)
			: currentDate,
	});

	try {
		const res = await axios.get<ResponseControl>(
			`${CONTROL_SERVICE_ENDPOINT}/api/v1/${cityId}/control?${queryString}`,
			{
				headers: {
					Authorization: `Bearer ${await getApiToken(cityId)}`,
				},
			}
		);
		return res.data;
	} catch (err) {
		if ((err as AxiosError).response.status === 404) {
			return undefined;
		}
		throw err;
	}
}

export async function patchControl(
	controlId: string,
	cityId: string,
	payload: UpdateControlPayload
) {
	const res = await axios.patch<ResponseControl>(
		`${CONTROL_SERVICE_ENDPOINT}/api/v1/${cityId}/control/${controlId}`,
		payload,
		{
			headers: {
				Authorization: `Bearer ${await getApiToken(cityId)}`,
			},
		}
	);
	logger.debug(`Control updated`, payload as any, { cityId, controlId, tag: "control.patch" });
	return res.data;
}

export function createPlateHash(plate: string, salt: string): string {
	const hashedSalt = createHash("sha1").update(salt).digest("base64");
	return createHash("sha1")
		.update(plate + hashedSalt)
		.digest("base64")
		.substring(0, 10);
}