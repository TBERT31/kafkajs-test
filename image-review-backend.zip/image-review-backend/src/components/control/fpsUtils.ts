import qs from "querystring";
import { Fps } from "@egis-smartcity/parking";
import axios, { AxiosError, AxiosResponse } from "axios";
import axiosRetry from "axios-retry";
import getApiToken from "../../utils/citiesCredentials";
import logger from "../../utils/logger";
import {
	FPS_DISPATCHER_ENDPOINT,
	MEDIA_REQUEST_MAX_RETRIES,
	FPS_NFPS_MAX_RETRIES,
	TERMINAL_TYPE,
} from "../../utils/secrets";
import { ErrorMessage } from "./controlModel";

export interface FpsLocation {
	latitude: number;
	longitude: number;
	accuracy: number;
}

/**
 * Send a fps with the following parameters :
 * @param fps The actual fps
 * @param cityId The city in witch the fps is send
 * @param controlId The controlId used to log the debug message in the console
 * @param jwt Jwt used to authenticate to the fps server
 * @param limit Date after which we stop to retry to send the fps in case of error
 */
export async function sendFps(
	fps: Fps,
	cityId: string,
	controlId: string,
	jwt: string,
	limit: Date,
	location: FpsLocation
): Promise<AxiosResponse> {
	// Send FPS first
	// we want to treat the status error manualy
	const axiosFpsClient = axios.create({
		validateStatus: (status) => status < 500,
	});
	let i = 0;
	axiosRetry(axiosFpsClient, {
		retryDelay: axiosRetry.exponentialDelay,
		retries: FPS_NFPS_MAX_RETRIES,
		retryCondition: (error: AxiosError) => {
			// either it worked (ie status = 201), either the api is missused (ie status = 4xx)
			// we could be more specific later if needed
			if (error.response.status < 500) {
				return false;
			}
			// no one can no longer verbalize the control
			if (new Date() > limit) {
				return false;
			}
			// error >= 500 are server error, so we retry
			logger.silly(`#${i++} request retry for FPS #${fps.fineLegalId} / control #${controlId}`);
			return true;
		},
	});

	const qryParams = qs.stringify({ ...location });
	const requestUrl = `${FPS_DISPATCHER_ENDPOINT}/api/v1/${cityId}/fines?${qryParams}`;

	return axiosFpsClient.post(
		requestUrl,
		{
			...fps,
			terminalType: TERMINAL_TYPE,
		},
		{
			headers: { "X-Bearer-Token": jwt },
		}
	);
}

export async function sendFpsMedia(
	cityId: string,
	fpsData: Fps,
	mediaUrl: string,
	fineId: string,
	token: string
) {
	const apiToken = await getApiToken(cityId);
	logger.info(`Sending media for FPS #${fpsData.fineLegalId} - (${mediaUrl})`);
	let i = 0;
	const mediaClient = axios.create();
	axiosRetry(mediaClient, {
		retryDelay: axiosRetry.exponentialDelay,
		retries: MEDIA_REQUEST_MAX_RETRIES,
		retryCondition: (error) => {
			logger.silly(
				`#${i++} download request retry for media of FPS #${fpsData.fineLegalId} [${mediaUrl}]`
			);
			return true;
		},
	});

	logger.info(`Downloading photo ${mediaUrl} for FPS ${fpsData.fineLegalId}`);
	const blob = await mediaClient.get(mediaUrl, {
		headers: { Authorization: `Bearer ${apiToken}` },
		responseType: "arraybuffer",
	});
	const base64data = Buffer.from(blob.data).toString("base64");
	const mediaName = mediaUrl.split("/").pop();
	const body = {
		matricule: fpsData.agent.agentId,
		filename: mediaName,
		accuracy: 1,
		fineLegalId: fpsData.fineLegalId,
		fineId,
		name: mediaName,
		photo: base64data,
		longitude: fpsData.statementLocation.longitude,
		latitude: fpsData.statementLocation.latitude,
	};

	const fpsMediaClient = axios.create();
	i = 0;
	axiosRetry(fpsMediaClient, {
		retryDelay: axiosRetry.exponentialDelay,
		retries: MEDIA_REQUEST_MAX_RETRIES,
		retryCondition: (error) => {
			logger.silly(
				`#${i++} upload request retry for media of FPS #${fpsData.fineLegalId} [${mediaUrl}]`
			);
			return true;
		},
	});
	await fpsMediaClient
		.post(`${FPS_DISPATCHER_ENDPOINT}/api/v1/${cityId}/media`, body, {
			headers: { "X-Bearer-Token": token },
		})
		.then(() => {
			logger.info(`Media sent for FPS #${fpsData.fineLegalId} - (${mediaUrl})`);
		})
		.catch((err) =>
			logger.error(`Unable to send media ${fpsData.fineLegalId} / ${mediaUrl}`, err.toString())
		);
}

function convertError(message: any, fps: Fps): ErrorMessage {
	const error = message?.errors[0];
	switch (error?.code?.toString()) {
		case "1001":
			return {
				code: "fps.error.invalidStructure",
				description: `Invalid request structure`,
				reason: { response: message },
			};
		case "1002":
			return {
				code: "fps.error.invalidFineLegalId",
				description: `Invalid fine legal id format (${fps.fineLegalId})`,
				reason: { fineLegalId: fps.fineLegalId },
			};
		case "1003":
			return {
				code: "fps.error.conflict",
				description: `Fine legal id ${fps.fineLegalId} already exist`,
				reason: {
					fineLegalId: fps.fineLegalId,
				},
			};
		case "1004":
			return {
				code: "fps.error.unknownZoneId",
				description: `Unknown ${fps.zoneId} zone id`,
				reason: { zoneId: fps.zoneId },
			};
		case "1005":
			return {
				code: "fps.error.invalidStatementDatetime",
				description: `Invalid statement date time (${fps.statementDatetime})`,
				reason: { statementDatetime: fps.statementDatetime },
			};
		case "1006":
			return {
				code: "fps.error.invalidFinePrice",
				description: `Invalid fine price (${fps.finePrice})`,
				reason: { finePrice: fps.finePrice },
			};
		case "1007":
			return {
				code: "fps.error.invalidValidityDatetime",
				description: `Invalid validity date time (${fps.validityDatetime})`,
				reason: { validityDatetime: fps.validityDatetime },
			};
		case "1008":
			return {
				code: "fps.error.invalidType",
				description: `Invalid fps ${fps.type} type `,
				reason: { type: fps.type },
			};
		case "1009":
			return {
				code: "fps.error.invalidReducedDatetime",
				description: `Invalid reduced date time (${fps.reducedDatetime})`,
				reason: { reducedDatetime: fps.reducedDatetime },
			};
		case "1010":
			return {
				code: "fps.error.invalidReducedFinePrice",
				description: `Invalid reduced fine price (${fps.reducedFinePrice})`,
				reason: { reducedFinePrice: fps.reducedFinePrice },
			};
		case "1011":
			return {
				code: "fps.error.invalidFineLegalId",
				description: `Invalid fine legal id (${fps.fineLegalId})`,
				reason: { fineLegalId: fps.fineLegalId },
			};
		case "1012":
			return {
				code: "fps.error.unauthorizedFieldModification",
				description: `Unauthorized field modification`,
				reason: {},
			};
		case "1013":
			return {
				code: "fps.error.inconsistanteModification",
				description: `Inconsistante modification`,
				reason: {},
			};
		case "1014":
			return {
				code: "fps.error.unknownParkId",
				description: `Unknown ${fps.parkId} park id`,
				reason: { parkId: fps.parkId },
			};
		case "1015":
			return {
				code: "fps.error.unreconizedLicencePlate",
				description: `Unreconized ${fps.licensePlate.plate} licence plate`,
				reason: {},
			};
		default:
			return {
				code: "fps.error.unknownInputError",
				description: `An unknown input error occured. Please try again.`,
				reason: { errors: message?.errors },
			};
	}
}

/**
 * Return formalized error message for the front-end depending of the status code
 * @param response fps server response
 * @param fps fps data that may be used to fill the reason field with useful data
 */
export function formatFpsError(response: AxiosResponse, fps: Fps): ErrorMessage {
	const status = response.status;
	switch (status) {
		case 401:
			return {
				code: "fps.error.unauthorized",
				description: `401 - Unauthorized`,
				reason: {},
			};
		case 403:
			return {
				code: "fps.error.forbidden",
				description: `403 Forbidden`,
				reason: {},
			};
		case 404:
			return {
				code: "fps.error.fpsNotFound",
				description: `FPS not found`,
				reason: {},
			};
		case 409:
			return {
				code: "fps.error.conflict",
				description: `Fine legal id ${fps.fineLegalId} already exist`,
				reason: {
					fineLegalId: fps.fineLegalId,
				},
			};
		case 412:
			return {
				code: "fps.error.preConditionFailled",
				description: `Pre condition failled`,
				reason: {},
			};
		case 400:
		case 422:
			return convertError(response.data, fps);
		case 500:
			return {
				code: "fps.error.internalSeverError",
				description: `Internal sever error`,
				reason: {
					response: response.data,
				},
			};
		default: {
			throw new Error(`unknown fps server response error (status ${status})`);
		}
	}
}
