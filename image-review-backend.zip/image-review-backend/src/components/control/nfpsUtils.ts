import { Nfps } from "@egis-smartcity/parking";
import axios, { AxiosResponse } from "axios";
import axiosRetry from "axios-retry";
import getApiToken from "../../utils/citiesCredentials";
import logger from "../../utils/logger";
import {
	NFPS_DISPATCHER_ENDPOINT,
	MEDIA_REQUEST_MAX_RETRIES,
	FPS_NFPS_MAX_RETRIES,
	TERMINAL_TYPE,
	MEDIA_REQUEST_DELAY,
} from "../../utils/secrets";
import { ErrorMessage } from "./controlModel";

/**
 * Send a nfps with the following parameters :
 * @param nfps The actual nfps
 * @param cityId The city in witch the nfps is send
 * @param controlId The controlId used to log the debug message in the console
 * @param jwt Jwt used to authenticate to the nfps server
 * @param limit Date after which we stop to retry to send the nfps in case of error
 */
export async function sendNfps(
	nfps: Nfps,
	cityId: string,
	controlId: string,
	jwt: string,
	limit: Date
): Promise<AxiosResponse> {
	const requestUrl = `${NFPS_DISPATCHER_ENDPOINT}/api/v1/${cityId}/nfps?terminalType=${TERMINAL_TYPE}`;
	const axiosNfpsClient = axios.create({
		validateStatus: (status) => status < 500,
	});
	let i = 0;
	axiosRetry(axiosNfpsClient, {
		retryDelay: () => MEDIA_REQUEST_DELAY,
		retries: FPS_NFPS_MAX_RETRIES,
		retryCondition: (error) => {
			// either it worked (ie status = 201), either the api is missused (ie status = 4xx)
			// we could be more specific later if needed
			if (error.response.status < 500) {
				return false;
			}
			// no one can no longer verbalize the control
			if (new Date() > limit) {
				return false;
			}

			logger.silly(`#${i++} request retry for NFPS #${nfps.id} / control #${controlId}`);
			// debugLog(error);
			return true;
		},
	});

	return axiosNfpsClient.post<Nfps>(requestUrl, nfps, {
		headers: { "X-Bearer-Token": jwt },
	});
}

export async function sendNfpsMedia(
	cityId: string,
	nfpsData: Nfps,
	mediaUrl: string,
	nfpsId: string,
	token: string
) {
	const apiToken = await getApiToken(cityId);
	logger.info(`Sending media for NFPS #${nfpsId} - (${mediaUrl})`);
	let i = 0;
	const client = axios.create();
	axiosRetry(client, {
		retryDelay: () => MEDIA_REQUEST_DELAY,
		retries: MEDIA_REQUEST_MAX_RETRIES,
		retryCondition: (error) => {
			// debugLog(error);
			logger.silly(
				`#${i++} request retry for media of NFPS #${nfpsId} [${mediaUrl} (${
					error.response.status
				})]`
			);
			return true;
		},
	});

	logger.info(`Downloading photo ${mediaUrl} for NFPS ${nfpsId}`);
	const blob = await client.get(mediaUrl, {
		headers: { Authorization: `Bearer ${apiToken}` },
		responseType: "arraybuffer",
	});
	const base64data = Buffer.from(blob.data).toString("base64");
	const mediaName = mediaUrl.split("/").pop();
	const body = {
		name: mediaName,
		filename: mediaName,
		photo: base64data,
		idNFPS: nfpsId,
		longitude: nfpsData.position.lon,
		latitude: nfpsData.position.lat,
	};

	await client
		.post(`${NFPS_DISPATCHER_ENDPOINT}/api/v1/${cityId}/media`, body, {
			headers: { "X-Bearer-Token": token },
		})
		.then(() => {
			logger.info(`Media sent for NFPS #${nfpsId} - (${mediaUrl})`);
		})
		.catch((err) => logger.error(`Unable to send media ${nfpsId} / ${mediaUrl}`, err.toString()));
}

/**
 * Return formalized error message for the front-end depending of the status code
 * @param response fps server response
 * @param nfps fps data that may be used to fill the reason field with useful data
 */
export function formatNfpsError(response: AxiosResponse, nfps: Nfps): ErrorMessage {
	const status = response.status;
	switch (status) {
		case 422:
			return {
				code: "nfps.error.badParameters",
				description: `400 - Bad parameters`,
				reason: {
					response: response.data,
				},
			};
		case 401:
			return {
				code: "nfps.error.unauthorized",
				description: `401 - Unauthorized`,
				reason: {},
			};
		case 403:
			return {
				code: "nfps.error.forbidden",
				description: `403 Forbidden`,
				reason: {},
			};
		case 404:
			return {
				code: "nfps.error.nfpsNotFound",
				description: `NFPS ${nfps.id} not found`,
				reason: {
					id: nfps.id,
				},
			};
		case 409:
			return {
				code: "nfps.error.conflict",
				description: `NFPS ${nfps.id} already exist`,
				reason: {
					id: nfps.id,
				},
			};
		case 422:
			return {
				code: "nfps.error.unprocessableEntity",
				description: `Unprocessable entity`,
				reason: {
					response: response.data,
				},
			};
		case 500:
			return {
				code: "nfps.error.internalSeverError",
				description: `Internal sever error`,
				reason: {
					status,
					response: response.data,
				},
			};
		default: {
			throw new Error(`unknown nfps server response error (status ${status})`);
		}
	}
}
