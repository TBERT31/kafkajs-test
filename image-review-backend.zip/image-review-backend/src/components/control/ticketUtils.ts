import Axios from "axios";
import QueryString from "qs";
import getApiToken from "../../utils/citiesCredentials";
import logger from "../../utils/logger";
import { TICKET_DISPATCHER_ENDPOINT } from "../../utils/secrets";
import { DispatcherTicketRes, ResponseControl } from "./controlModel";

export async function checkControlValidity(cityId: string, control: ResponseControl) {
	try {
		const res = await Axios.get<DispatcherTicketRes>(
			`${TICKET_DISPATCHER_ENDPOINT}/api/v1/${cityId}/tickets?${QueryString.stringify({
				licenseplate: control.licensePlate,
				latitude: control.latitude,
				longitude: control.longitude,
				scandate: control.controlDate,
				terminaltype: "AUTOMATIC",
				requestSrc: "ImageReview",
			})}`,
			{
				headers: {
					"x-bearer-token": `Bearer ${await getApiToken(cityId)}`,
				},
			}
		);
		return res.data;
	} catch (error) {
		logger.error(
			`[ASSIGN][cityId:${cityId}][controlId:${control.controlId}] - Error asking Control validity`,
			error
		);
		throw error;
	}
}
