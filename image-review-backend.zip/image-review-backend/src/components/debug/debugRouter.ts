import { RequestWithJwt } from "@egis-auth/express-security";
import axios, { AxiosError } from "axios";

import { Router } from "express";

import getApiToken from "../../utils/citiesCredentials";
import logger from "../../utils/logger";
import { CONTROL_SERVICE_ENDPOINT } from "../../utils/secrets";
import {
	PdaJwt,
	authenticatedMiddleware,
	cityAgentMiddleware,
} from "../../utils/securityMiddleware";
import { PaginatedResult, ResponseControl } from "../control/controlModel";
import { minimalRoleResolver } from "../control/controlUtil";

const router = Router();

router.get(
	"/control-service/get-control",
	authenticatedMiddleware(minimalRoleResolver),
	cityAgentMiddleware,
	async (req: RequestWithJwt<PdaJwt>, res) => {
		const cityId = req.jwt.codeVille;
		logger.debug("[CS-CONTROL]", {
			cityId,
		});
		const apiJwt = await getApiToken(req.jwt.codeVille);

		axios
			.get<PaginatedResult<ResponseControl>>(
				`${CONTROL_SERVICE_ENDPOINT}/api/v1/${cityId}/control?limit=1`,
				{
					headers: {
						Authorization: `Bearer ${apiJwt}`,
					},
				}
			)
			.then((response) => {
				res.status(response.status).json(response.data.results[0]);
			})
			.catch((err: AxiosError) => {
				res.status(err.response.status).json(err.response.data);
			});
	}
);

export default router;
