export interface AgentDailySelfStatistics {
	averageControlDuration: number;
	controlCount: number;
}

export interface AgentDailyStatistics {
	agentId: string;
	processed: number;
	emittedFps: number;
	emittedNfps: number;
	agentSent: number;
	averageControlDuration: number;
}

export interface LapiDailyStatistics {
	lapiId: string;
	processed: number;
}

export type DecisionsCount = {
	FPS: number;
	NFPS: number;
	VERIFY: number;
};

export type DecisionActivityItem = DecisionsCount & {
	date: string;
};

export type DecisionActivityType = "hour" | "day";

export interface DecisionsStatistics {
	query: {
		start: string;
		end: string;
		activity?: DecisionActivityType;
		vehicleCategory?: (string | null)[];
	};
	total: DecisionsCount;
	activity?: DecisionActivityItem[];
}

