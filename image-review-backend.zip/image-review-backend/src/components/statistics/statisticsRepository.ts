import sql from "sql-template-strings";
import pool from "../../utils/db";
import { AgentDailySelfStatistics, AgentDailyStatistics, DecisionActivityItem, DecisionActivityType, DecisionsCount, DecisionsStatistics, LapiDailyStatistics } from "./statisticsModel";

/**
 * Returns agent's daily self statistics
 * @param AgentId Agent ID
 */
export function getAgentDailySelfStatistics(cityId: string, agentId: string) {
	return new Promise<AgentDailySelfStatistics>(async (resolve, reject) => {
		try {
			const qryResult = await pool.query<AgentDailySelfStatistics>(
				sql`
        select
          extract(epoch from percentile_disc(0.5) within group (order by sq.diff)) as "averageControlDuration",
          count(sq)::integer as "controlCount"
        from (
          select age(submitted_at, assigned_at ) as diff
          from "control".decisions_history dh
            where
              agent_id = ${agentId}
              and city_id = ${cityId}
              and submitted_at > DATE_TRUNC('day', now())
              and submitted_at < DATE_TRUNC('day', now() + interval '1 day')
          ) sq;
        ;`
			);
			resolve({
				averageControlDuration: 0,
				controlCount: 0,
				...qryResult.rows[0],
			});
		} catch (err) {
			reject(err);
		}
	});
}

export function getStatisticsGroupedByLapi(
	cityId: string,
	startDate: string,
	endDate: string,
	vehicleCategory?: (string | null)[]
) {
	return new Promise<LapiDailyStatistics[]>(async (resolve, reject) => {
		try {
			let vehicleFilter = sql` `;
			if (vehicleCategory instanceof Array)
				vehicleFilter = sql` and (
          SELECT CASE
            WHEN dh.vehicle_category LIKE ANY(${vehicleCategory.filter(
							(value) => value !== null
						)}) THEN TRUE
            WHEN dh.vehicle_category is NULL and ${vehicleCategory.some(
							(value) => value === null
						)} THEN true
            ELSE FALSE
          END
        ) `;
			const query = sql`
        select dh.lapi_id as "lapiId", COUNT(*) as processed
      from "control".decisions_history dh
      where dh.submitted_at > ${startDate}::timestamptz
        and dh.submitted_at < ${endDate}::timestamptz
        and dh.city_id = ${cityId}
        and dh.status = 'DONE'
        `
				.append(vehicleFilter)
				.append(`group by dh.lapi_id`);

			const qryResult = await pool.query<LapiDailyStatistics>(query);
			resolve(qryResult.rows);
		} catch (err) {
			reject(err);
		}
	});
}

export function getStatisticsGroupedByAgent(
	cityId: string,
	startDate: string,
	endDate: string,
	vehicleCategory?: (string | null)[]
) {
	return new Promise<AgentDailyStatistics[]>(async (resolve, reject) => {
		try {
			let vehicleFilter = sql` `;
			if (vehicleCategory instanceof Array)
				vehicleFilter = sql` and (
          SELECT CASE
            WHEN dh.vehicle_category LIKE ANY(${vehicleCategory.filter(
							(value) => value !== null
						)}) THEN TRUE
            WHEN dh.vehicle_category is NULL and ${vehicleCategory.some(
							(value) => value === null
						)} THEN true
            ELSE FALSE
          END
        ) `;

			const qryResult = await pool.query<AgentDailyStatistics>(
				sql`
          select
            dh.agent_id as "agentId",
            count(*)::integer as processed,
            sum(case WHEN dh.decision = 'FPS' THEN 1 else 0 end)::integer as "emittedFps",
            sum(case WHEN dh.decision = 'NFPS' THEN 1 else 0 end)::integer as "emittedNfps",
            sum(case WHEN dh.decision = 'VERIFY' THEN 1 else 0 end)::integer as "agentSent",
            extract(epoch from percentile_disc(0.5) within group (order by age(done_at, assigned_at ))) as "averageControlDuration"
          from "control".decisions_history dh
          where
            dh.agent_id is not NULL
            and dh.city_id = ${cityId}
            and dh.submitted_at > ${startDate}::timestamptz
            and dh.submitted_at < ${endDate}::timestamptz`
					.append(vehicleFilter)
					.append(` group by dh.agent_id;`)
			);
			resolve(qryResult.rows);
		} catch (err) {
			reject(err);
		}
	});
}

export function getStatisticsGroupedByDecisions(
	cityId: string,
	startDate: string,
	endDate: string,
	activityType?: DecisionActivityType,
	vehicleCategory?: (string | null)[]
) {
	return new Promise<DecisionsStatistics>(async (resolve, reject) => {
		try {
			let vehicleFilter = sql` `;
			if (vehicleCategory instanceof Array)
				vehicleFilter = sql` and (SELECT CASE
            WHEN dh.vehicle_category LIKE ANY(${vehicleCategory.filter(
							(value) => value !== null
						)}) THEN TRUE
            WHEN dh.vehicle_category is NULL and ${vehicleCategory.some(
							(value) => value === null
						)} THEN true
            ELSE FALSE
          END) `;
			const totalQuery = sql`
        select
          sum(case WHEN dh.decision = 'FPS' THEN 1 else 0 end)::integer as "FPS",
          sum(case WHEN dh.decision = 'NFPS' THEN 1 else 0 end)::integer as "NFPS",
          sum(case WHEN dh.decision = 'VERIFY' THEN 1 else 0 end)::integer as "VERIFY"
        from "control".decisions_history dh
        where
          dh.city_id = ${cityId}
          and dh.submitted_at > ${startDate}::timestamptz
          and dh.submitted_at < ${endDate}::timestamptz
      `.append(vehicleFilter);
			const totalQryResult = await pool.query<DecisionsCount>(totalQuery);

			let activity: DecisionActivityItem[] | undefined = undefined;

			if (activityType) {
				const activityQuery = sql`
        select
          date_trunc('`
					.append(activityType)
					.append(
						sql`', dh.submitted_at) as "date",
            sum(case WHEN dh.decision = 'FPS' THEN 1 else 0 end)::integer as "FPS",
            sum(case WHEN dh.decision = 'NFPS' THEN 1 else 0 end)::integer as "NFPS",
            sum(case WHEN dh.decision = 'VERIFY' THEN 1 else 0 end)::integer as "VERIFY"
          from "control".decisions_history dh
          where
            dh.agent_id is not NULL
            and dh.city_id = ${cityId}
            and dh.submitted_at > ${startDate}::timestamptz
            and dh.submitted_at < ${endDate}::timestamptz`
					)
					.append(vehicleFilter).append(`
          group by date_trunc('${activityType}', dh.submitted_at)
          order by date_trunc('${activityType}', dh.submitted_at) ASC
        `);
				const activityQryResult = await pool.query<DecisionActivityItem>(activityQuery);

				activity = activityQryResult.rows;
			}

			resolve({
				query: {
					start: startDate,
					end: endDate,
					activity: activityType,
					vehicleCategory: vehicleCategory,
				},
				total: totalQryResult.rows[0],
				activity,
			});
		} catch (err) {
			reject(err);
		}
	});
}
