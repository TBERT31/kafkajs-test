import { RequestWithJwt } from "@egis-auth/express-security";
import { Router } from "express";

import logger from "../../utils/logger";
import { authenticatedMiddleware, PdaJwt } from "../../utils/securityMiddleware";

import {
	DecisionActivityType,
} from "./statisticsModel";

import {
	getAgentDailySelfStatistics,
	getStatisticsGroupedByLapi,
	getStatisticsGroupedByAgent,
	getStatisticsGroupedByDecisions,
} from "./statisticsRepository";

const router = Router();

function isArrayOfStringOrNull(value: any): value is (string | null)[] {
	return Array.isArray(value) && value.every((item) => typeof item == "string" || item === null);
}

/**
 * Returns agent self-statistics of the day
 */
router.get(
	"/agent/self",
	authenticatedMiddleware("ROLE_USER"),
	async (req: RequestWithJwt<PdaJwt>, res) => {
		try {
			const agentId = req.jwt.matricule;
			const cityId = req.jwt.codeVille;
			if (!agentId) return res.status(403).json({ message: "Missing matricule" });
			if (!cityId) return res.status(403).json({ message: "Missing city ID" });
			const dailyStats = await getAgentDailySelfStatistics(cityId, agentId);
			res.json(dailyStats);
		} catch (err) {
			logger.error(err);
			res.status(500).send(err.message);
		}
	}
);

/**
 * Returns day's statistics grouped by agents
 */
router.get(
	"/agent",
	authenticatedMiddleware("ROLE_USER"),
	async (req: RequestWithJwt<PdaJwt>, res) => {
		try {
			const cityId = req.jwt.codeVille;
			if (!cityId) return res.status(403).json({ message: "Missing city ID" });

			const startDate = req.query.startDate
				? new Date(req.query.startDate.toString()).toISOString()
				: undefined;
			const endDate = req.query.endDate
				? new Date(req.query.endDate.toString()).toISOString()
				: undefined;
			const jsonVehicleCategory = req.query.vehiclecategory as string | undefined;
			let vehicleCategory: (string | null)[] | undefined = undefined;
			if (typeof jsonVehicleCategory == "string") {
				try {
					const parsedJsonVehicleCategory = JSON.parse(jsonVehicleCategory) as unknown;
					if (!isArrayOfStringOrNull(parsedJsonVehicleCategory)) {
						throw new Error("vehiclecategory is not an array of: string or null");
					}
					vehicleCategory = parsedJsonVehicleCategory;
					if (Array.isArray(parsedJsonVehicleCategory)) {
						JSON.parse(jsonVehicleCategory).map((value: any) => {
							return typeof value === "string" || value === null;
						});
					}
				} catch (err) {
					res.status(422).send({
						error: "bad value for vehicleCategory in vehicle parameters",
						message: err.message,
					});
					return;
				}
			}

			if (!startDate || !endDate)
				return res.status(400).json({
					message: "Parameters 'startDate' and 'endDate' must be provided",
				});

			const dailyStats = await getStatisticsGroupedByAgent(
				cityId,
				startDate,
				endDate,
				vehicleCategory
			);

			res.json(dailyStats);
		} catch (err) {
			logger.error(err);
			res.status(500).send(err.message);
		}
	}
);

/**
 * Returns day's statistics grouped by LAPI vehicles
 */
router.get(
	"/lapi",
	authenticatedMiddleware("ROLE_USER"),
	async (req: RequestWithJwt<PdaJwt>, res) => {
		try {
			const cityId = req.jwt.codeVille;
			if (!cityId) return res.status(403).json({ message: "Missing city ID" });
			// const cityConfig = await getCityConfigs(req.jwt.codeVille);
			const startDate = req.query.startDate
				? new Date(req.query.startDate.toString()).toISOString()
				: undefined;
			const endDate = req.query.endDate
				? new Date(req.query.endDate.toString()).toISOString()
				: undefined;
			const jsonVehicleCategory = req.query.vehiclecategory as string | undefined;
			let vehicleCategory: (string | null)[] | undefined = undefined;
			if (typeof jsonVehicleCategory == "string") {
				try {
					const parsedJsonVehicleCategory = JSON.parse(jsonVehicleCategory) as unknown;
					if (!isArrayOfStringOrNull(parsedJsonVehicleCategory)) {
						throw new Error("vehiclecategory is not an array of: string or null");
					}
					vehicleCategory = parsedJsonVehicleCategory;
					if (Array.isArray(parsedJsonVehicleCategory)) {
						JSON.parse(jsonVehicleCategory).map((value: any) => {
							return typeof value === "string" || value === null;
						});
					}
				} catch (err) {
					res.status(422).send({
						error: "bad value for vehicleCategory in vehicle parameters",
						message: err.message,
					});
					return;
				}
			}
			if (!startDate || !endDate)
				return res.status(400).json({
					message: "Parameters 'startDate' and 'endDate' must be provided",
				});

			const lapiStats = await getStatisticsGroupedByLapi(
				cityId,
				startDate,
				endDate,
				vehicleCategory
			);
			res.json(lapiStats);
		} catch (err) {
			logger.error(err);
			res.status(500).send(err.message);
		}
	}
);

/**
 * Returns day's statistics grouped by decisions
 */
router.get(
	"/decisions",
	authenticatedMiddleware("ROLE_USER"),
	async (req: RequestWithJwt<PdaJwt>, res) => {
		try {
			const cityId = req.jwt.codeVille;
			if (!cityId) return res.status(403).json({ message: "Missing city ID" });

			const startDate = req.query.startDate
				? new Date(req.query.startDate.toString()).toISOString()
				: undefined;
			const endDate = req.query.endDate
				? new Date(req.query.endDate.toString()).toISOString()
				: undefined;
			const jsonVehicleCategory = req.query.vehiclecategory as string | undefined;
			let vehicleCategory: (string | null)[] | undefined = undefined;
			if (typeof jsonVehicleCategory == "string") {
				try {
					const parsedJsonVehicleCategory = JSON.parse(jsonVehicleCategory) as unknown;
					if (!isArrayOfStringOrNull(parsedJsonVehicleCategory)) {
						throw new Error("vehiclecategory is not an array of: string or null");
					}
					vehicleCategory = parsedJsonVehicleCategory;
					if (Array.isArray(parsedJsonVehicleCategory)) {
						JSON.parse(jsonVehicleCategory).map((value: any) => {
							return typeof value === "string" || value === null;
						});
					}
				} catch (err) {
					res.status(422).send({
						error: "bad value for vehicleCategory in vehicle parameters",
						message: err.message,
					});
					return;
				}
			}
			if (!startDate || !endDate)
				return res.status(400).json({
					message: "Parameters 'startDate' and 'endDate' must be provided",
				});

			const activityType = req.query.activity
				? (String(req.query.activity) as DecisionActivityType)
				: undefined;
			if (activityType && !["hour", "day"].includes(activityType)) {
				return res.status(400).json({
					message: `Value '${activityType}' for property 'activity' is invalid. Must be either 'day' or 'hour'.`,
				});
			}

			const decisionsStats = await getStatisticsGroupedByDecisions(
				cityId,
				startDate,
				endDate,
				activityType,
				vehicleCategory
			);
			res.json(decisionsStats);
		} catch (err) {
			logger.error(err);
			res.status(500).send(err.message);
		}
	}
);

export default router;
