import dotenv from "dotenv";
import yargs from "yargs";
import { hideBin } from "yargs/helpers";
import { additionalDataCleanup, additionalDataCleanupArgs } from "./command/additionalDataCleanup";
import { historyCleanup, historyCleanupArgs } from "./command/historyCleanup";
import { loadService, serviceArgs } from "./command/loadService";
import json from "./utils/package";

dotenv.config();

const { description } = json;

export async function app() {
	await yargs(hideBin(process.argv))
		.usage(description)
		.command("$0", "start the server", serviceArgs, loadService)
		.command(
			"history-cleanup",
			"Remove old history from database",
			historyCleanupArgs,
			historyCleanup
		)
		.command(
			"additional-data-cleanup",
			"Remove old metadata from database",
			additionalDataCleanupArgs,
			additionalDataCleanup
		)
		.wrap(Math.min(100, yargs().terminalWidth()))
		.parse();
}
