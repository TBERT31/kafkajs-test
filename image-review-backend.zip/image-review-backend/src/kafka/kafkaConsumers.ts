import dotenv from "dotenv";
import logger, { event } from "tsdz-logger";
import { setupAssignControlConsumer } from "./kafkaSetup";
dotenv.config();

export const startKafkaConsumers = async () => {
	//await logger.monit("mon.action", async () => {
        //event("assigned!",{agent:300, control:"qmsldkjfqsdlf"});
		try {
			if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "QUALITY") {
				logger.info("Kafka consumer setup initiated for Image Review QUALITY mode. 💎");
				await setupAssignControlConsumer();
			} else if (process.env.STANDARD_MODE_OR_QUALITY_MODE === "STANDARD") {
				logger.info("Kafka consumer setup skipped for Image Review STANDARD mode. 🚀");
			} else {
				logger.info(
					`STANDARD_MODE_OR_QUALITY_MODE is set to: ${process.env.STANDARD_MODE_OR_QUALITY_MODE}`
				);
				logger.error(
					"Invalid value for environment variable 'STANDARD_MODE_OR_QUALITY_MODE'. It must be either 'QUALITY' or 'STANDARD'."
				);
				throw new Error(
					"Invalid environment configuration: 'STANDARD_MODE_OR_QUALITY_MODE' must be 'QUALITY' or 'STANDARD'."
				);
			}
		} catch (error) {
			logger.error("Error during Kafka consumer setup", error);
			throw error;
		}
	//});
};
