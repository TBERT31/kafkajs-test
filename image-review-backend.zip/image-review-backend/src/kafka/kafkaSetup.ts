import { Kafka } from "kafkajs";
import logger from "tsdz-logger";
import { createControlForQualityCheck } from "../components/control/controlRepository";

const kafka = new Kafka({
	clientId: `IR - Mode : ${process.env.STANDARD_MODE_OR_QUALITY_MODE}`,
	brokers: process.env.KAFKA_ENDPOINTS.split(","),
});

const producer = kafka.producer();
const assignControlConsumer = kafka.consumer({ groupId: "control-assignment-group" });

// Use the producer created above to send messages to the mail queue
export const sendKafkaMessage = async (topic, messages) => {
	try {
		await producer.connect();
		logger.info(`Producing message to topic: ${topic}`);
		await producer.send({
			topic,
			messages: [{ value: messages }],
		});
		logger.info("Message produced successfully");
	} catch (error) {
		logger.error("Error producing Kafka message:", error);
	} finally {
		await producer.disconnect();
	}
};

// ➡️ sendKafkaMessage('control-assigned', 'Control assigned to agent').catch(console.error); // Example of use ⬅️

// Consumer used for get('/'), assignation control route
export const setupAssignControlConsumer = async () => {
	try {
		await assignControlConsumer.connect();
		await assignControlConsumer.subscribe({ topic: "control-assigned", fromBeginning: true });

		await assignControlConsumer.run({
			eachMessage: async ({ topic, partition, message }) => {
				try {
					const parsedMessage = JSON.parse(message.value.toString());
					logger.info(`Received message: ${JSON.stringify(parsedMessage, null, 2)}`);

					const controlId = parsedMessage.controlId;
					const cityId = parsedMessage.cityId;
					const agentIdImageReview = parsedMessage.agentId;
					const controlData = parsedMessage.control;

					await createControlForQualityCheck(controlId, cityId, agentIdImageReview, controlData);
				} catch (error) {
					logger.error(
						`Error processing message ${message.offset} from partition ${partition}`,
						error
					);
				}
			},
		});

		logger.info("Kafka consumer for control-assignment-topic is running.");
	} catch (error) {
		logger.error("Error during consumer setup", error);
	}
};
