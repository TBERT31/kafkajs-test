import { CityConfig as ParkingCityConfig, CityConfigSwagger } from "@egis-smartcity/parking";
import { TicketSwagger } from "@egis-smartcity/parking";
import logger from "tsdz-logger";
import getApiToken from "./citiesCredentials";
import citiesConfig from "./configs";

import { CITIES_CONFIGS_CACHE_DURATION, STADE_API_AUTH_ENDPOINT } from "./secrets";

export type CityConfig = ParkingCityConfig & {
	review: {
		lapi: {
			lapiFilter?: (string | number)[];
		};
		controlReview: {
			retentionDelay: number;
		};
	};
};
export interface CachedCityConfig {
	storageDate: number;
	configs: Partial<CityConfig>;
}

const cityConfigsApi = new CityConfigSwagger.CityApi({
	...new TicketSwagger.Configuration({
		basePath: `${STADE_API_AUTH_ENDPOINT}/api/v2`,
	}),
	isJsonMime: () => true,
});

const citiesConfigsCache = new Map<string, CachedCityConfig>();

async function fetchCityConfigs(cityId: string): Promise<Partial<CityConfig>> {
	const cityJwt = await getApiToken(cityId);
	const res = await cityConfigsApi.getCityConfig({
		headers: {
			"X-Bearer-Token": `Bearer ${cityJwt}`,
		},
	});
	return res.data as Partial<CityConfig>;
}
async function newCityConfig(cityId: string): Promise<Partial<CityConfig>> {
	const renewedConfigs = await fetchCityConfigs(cityId);
	citiesConfigsCache.set(cityId, {
		storageDate: Date.now(),
		configs: renewedConfigs,
	});
	return renewedConfigs;
}
// export function getCityConfigs(cityId: string) {
//   return new Promise<Partial<CityConfig>>(async (resolve, reject) => {
//     try {
//       if (citiesConfigsCache.has(cityId)) {
//         const storedCityConfigs = citiesConfigsCache.get(cityId);
//         if (
//           Date.now() - CITIES_CONFIGS_CACHE_DURATION >
//           storedCityConfigs.storageDate
//         ) {
//           // config is expired, renewal required.
//           const renewedConfigs = await fetchCityConfigs(cityId);
//           citiesConfigsCache.set(cityId, {
//             storageDate: Date.now(),
//             configs: renewedConfigs
//           });
//           return resolve(renewedConfigs);
//         } else {
//           return resolve(storedCityConfigs.configs);
//         }
//       } else {
//         const newConfigs = await fetchCityConfigs(cityId);
//         citiesConfigsCache.set(cityId, {
//           storageDate: Date.now(),
//           configs: newConfigs
//         });
//         return resolve(newConfigs);
//       }
//     } catch (err) {
//       // logger.error(err);
//       return reject(err);
//     }
//   });
// }
export function getCityConfigs(cityId: string) {
	return new Promise<Partial<CityConfig>>(async (resolve, reject) => {
		try {
			return citiesConfigsCache.has(cityId) &&
				citiesConfigsCache.get(cityId).storageDate >= Date.now() - CITIES_CONFIGS_CACHE_DURATION
				? resolve(citiesConfigsCache.get(cityId).configs)
				: resolve(await newCityConfig(cityId));
		} catch (err) {
			logger.error(`[ASSIGN-CITYCONFIG][cityId:${cityId}] - ${err}`);
			return reject(err);
		}
	});
}

export function getCitiesConfigs() {
	return new Promise<Map<string, Partial<CityConfig>>>(async (resolve, reject) => {
		try {
			const confs = new Map<string, Partial<CityConfig>>();
			for (const [cityId] of citiesConfig) {
				const cityConfig = await getCityConfigs(cityId);
				confs.set(cityId, cityConfig);
			}
			resolve(confs);
		} catch (err) {
			return reject(err);
		}
	});
}
