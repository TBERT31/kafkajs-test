import { validateJwt } from "@egis-auth/jwt-utils";
import axios from "axios";
import citiesConfig from "./configs";

import { JWT_PUBLIC_KEY, STADE_API_AUTH_ENDPOINT } from "./secrets";

const tokens = new Map<string, string>();

function obtainToken(username: string, password: string) {
	// Prepare x-www-form-encoded payload
	const payload = new URLSearchParams();
	payload.append("_username", username);
	payload.append("_password", password);
	return axios
		.post<{ token: string }>(`${STADE_API_AUTH_ENDPOINT}/api/login_check`, payload)
		.then((response) => response.data.token);
}

export default async function getApiToken(cityId: string) {
	return new Promise<string>(async (resolve, reject) => {
		if (!citiesConfig.has(cityId))
			return reject(new Error(`No configuration available for city ${cityId}`));
		const config = citiesConfig.get(cityId);
		if (tokens.has(cityId)) {
			// Get JWT
			const token = tokens.get(cityId);

			// Check if JWT still valid
			try {
				validateJwt(token, { publicKey: JWT_PUBLIC_KEY, privateKey: "" });
				resolve(token);
			} catch (err) {
				// Token is invalid, get a new one
				try {
					const newToken = await obtainToken(
						config.apiCredentials.username,
						config.apiCredentials.password
					);
					tokens.set(cityId, newToken);
					// New token obtained, returning it.
					return resolve(newToken);
				} catch (renewErr) {
					return reject(renewErr);
				}
			}
		} else {
			try {
				const newToken = await obtainToken(
					config.apiCredentials.username,
					config.apiCredentials.password
				);
				tokens.set(cityId, newToken);
				// New token obtained, returning it.
				return resolve(newToken);
			} catch (renewErr) {
				return reject(renewErr);
			}
		}
	});
}
