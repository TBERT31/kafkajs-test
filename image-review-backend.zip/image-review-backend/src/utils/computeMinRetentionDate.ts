export default function computeMinRetentionDate(retentionDelay: number) {
	const minRetentionDate = new Date(
		// we set the offset accordingly to retentionDelay
		new Date().getTime() - retentionDelay * 1000 * 60 * 60 * 24
	);
	// we put deletion date to midnight. This method take the time zone into account
	minRetentionDate.setMilliseconds(0);
	minRetentionDate.setSeconds(0);
	minRetentionDate.setMinutes(0);
	minRetentionDate.setHours(0);
	return minRetentionDate;
}
