import fs from "fs";
import path from "path";
import logger from "./logger";
import { CITIES_CONFIG_PATH } from "./secrets";

export interface StadeApiCredential {
	username: string;
	password: string;
}

export interface CityConfig {
	apiCredentials: StadeApiCredential;
	licensePlateSalt: string;
}

const citiesConfig = new Map<string, CityConfig>();

try {
	const rawConfig = fs.readFileSync(path.resolve(CITIES_CONFIG_PATH), {
		encoding: "utf-8",
	});
	const decodedConfigs = JSON.parse(rawConfig) as { [key: string]: CityConfig };
	if (decodedConfigs) {
		for (const cityId in decodedConfigs) {
			citiesConfig.set(cityId, decodedConfigs[cityId]);
		}
	}
} catch (err) {
	logger.error(`Unable to load cities config file '${CITIES_CONFIG_PATH}' : ${err.message}`);
	process.exit(1);
}

export default citiesConfig;
