import pg from "pg";
import logger from "./logger";

const pool = new pg.Pool({
	// all valid client config options are also valid here
	// in addition here are the pool specific configuration parameters:
	// number of milliseconds to wait before timing out when connecting a new client
	// by default this is 0 which means no timeout
	connectionTimeoutMillis: 5000,
	// number of milliseconds a client must sit idle in the pool and not be checked out
	// before it is disconnected from the backend and discarded
	// default is 10000 (10 seconds) - set to 0 to disable auto-disconnection of idle clients
	idleTimeoutMillis: 5000,
	// maximum number of clients the pool should contain
	// by default this is set to 10.
	max: 50,
});
let storedClient: ManagedClient;

// var clientInstance: pg.Client =

// the pool will emit an error on behalf of any idle clients
// it contains if a backend error or network partition happens
// client.on("error", (err: Error) => {
//   logger.error("Unexpected error on idle client", err);
//   process.exit(-1);
// });

export interface ManagedClient {
	client: pg.PoolClient;
	release(): Promise<void>;
}

export async function getClient(cache: boolean = true): Promise<ManagedClient> {
	if (true || !cache || !storedClient) {
		const newClient = await pool.connect();
		function onErrorCallback(err: Error) {
			logger.error("Postgres error :", err);
			newClient.off("error", this);
			storedClient.release();
			storedClient = undefined;
		}

		newClient.once("error", onErrorCallback);

		const newRelease = async () => {
			newClient.off("error", onErrorCallback);
			newClient.release();
			storedClient = undefined;
		};
		storedClient = { client: newClient, release: newRelease };
	}

	return storedClient;
}

export default pool;
