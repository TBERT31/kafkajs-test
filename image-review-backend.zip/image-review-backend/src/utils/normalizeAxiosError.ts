import { AxiosError, AxiosResponse } from "axios";
import logger from "./logger";

export interface NormalizedAxiosError {
	target: string;
	status: number;
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	data: any;
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	headers: AxiosResponse<any>["headers"];
}

export default (targetUrl: string, error: AxiosError | AxiosResponse) => {
	const response = error instanceof Error ? error.response : error;
	const message = error instanceof Error ? error.response.data || error.message : response.data;
	logger.error("axios error", error as any);
	return {
		target: targetUrl,
		status: response.status || -1,
		data: response.data || message,
		headers: response.headers,
	};
};
