import fs from "fs";

const service: {
	description: string;
	version: string;
	name: string;
} = JSON.parse(fs.readFileSync("./package.json", { encoding: "utf-8" }));

export default service;
