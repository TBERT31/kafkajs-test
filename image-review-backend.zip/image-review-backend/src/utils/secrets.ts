import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import logger from "./logger";

dotenv.config();

export const PORT = process.env.PORT || 6065;

// JWT public key
if (!process.env.JWT_PUBLIC_PATH) {
	logger.error("Environement variable JWT_PUBLIC_PATH is missing, aborting.");
	process.exit(1);
}
export const JWT_PUBLIC_PATH = process.env.JWT_PUBLIC_PATH;

let pubkey = "";
try {
	pubkey = fs.readFileSync(path.resolve(JWT_PUBLIC_PATH), {
		encoding: "utf-8",
	});
} catch (err) {
	console.error(`Unable to read public key file '${JWT_PUBLIC_PATH}' :`, err.message);
	process.exit(1);
}

export const JWT_PUBLIC_KEY = pubkey;

export const CITIES_CONFIG_PATH = process.env.CITIES_CONFIG_PATH || undefined;

export const STADE_API_AUTH_ENDPOINT =
	process.env.STADE_API_AUTH_ENDPOINT || "http://localhost:8081";

export const LAPI_ENDPOINT = process.env.LAPI_ENDPOINT || "http://localhost:2715";

export const FPS_DISPATCHER_ENDPOINT =
	process.env.FPS_DISPATCHER_ENDPOINT || "http://localhost:8002";

export const NFPS_DISPATCHER_ENDPOINT =
	process.env.NFPS_DISPATCHER_ENDPOINT || "http://localhost:8003";

export const TICKET_DISPATCHER_ENDPOINT =
	process.env.TICKET_DISPATCHER_ENDPOINT || "http://localhost:8004";

export const CITIES_CONFIGS_CACHE_DURATION =
	+process.env.CITIES_CONFIGS_CACHE_DURATION || 1000 * 60 * 15; // 15 minutes cache storage

// Interval for checking overdue controls
export const CONTROL_CHECK_DELAY = +process.env.CONTROL_CHECK_DELAY || 5000;

// Time in milliseconds to add to processing delay in order to allow the agent
// to send his decision. Defaults to 30 seconds.
export const CONTROL_CHECK_JITTER = +process.env.CONTROL_CHECK_JITTER || 30000;

export const MEDIA_REQUEST_MAX_RETRIES = +process.env.REQUEST_MAX_RETRIES || 10;

export const MEDIA_REQUEST_DELAY = +process.env.MEDIA_REQUEST_DELAY || 3000;

export const FPS_NFPS_MAX_RETRIES = +process.env.FPS_NFPS_MAX_RETRIES || Number.MAX_SAFE_INTEGER;

export const TERMINAL_TYPE = "IMAGE_REVIEW";

export const DEBUG =
	process.env.DEBUG !== undefined
		? process.env.DEBUG === "true"
		: process.env.NODE_ENV === "development";

export const CONTROL_SERVICE_ENDPOINT =
	process.env.CONTROL_SERVICE_ENDPOINT || "http://localhost:40000";

export const CONTROL_SERVICE_IMG_ENDPOINT =
	process.env.CONTROL_SERVICE_IMG_ENDPOINT || "http://localhost:40000";

export const ASSIGNATION_QUEUE_TIMEOUT = process.env.ASSIGNATION_QUEUE_TIMEOUT
	? +process.env.ASSIGNATION_QUEUE_TIMEOUT
	: 15000;

export const CONTROL_REQUEST_QUEUE_PARALLEL_COUNT = process.env.CONTROL_REQUEST_QUEUE_PARALLEL_COUNT
	? +process.env.CONTROL_REQUEST_QUEUE_PARALLEL_COUNT
	: 1;
