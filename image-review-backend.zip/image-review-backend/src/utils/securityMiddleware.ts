import createAuthenticatedMiddleware, { RequestWithJwt } from "@egis-auth/express-security";
import { DecodedJwt } from "@egis-auth/jwt-utils";

import { Response } from "express";
import { JWT_PUBLIC_KEY } from "./secrets";

export interface PdaJwt extends DecodedJwt {
	username: string;
	terminalId: string;
	codeVille: string;
	matricule: string;
	id: string;
}

/**
 * Checks if the user is properly authenticated using Exyzt's JWT and has
 * correct roles
 */
export const authenticatedMiddleware = createAuthenticatedMiddleware<PdaJwt>({
	authorizationHeader: "X-Bearer-Token",
	publicKey: JWT_PUBLIC_KEY,
	privateKey: "",
});

/**
 * Checks that the user
 * @param req
 * @param res
 * @param next
 */
export const cityAgentMiddleware = (req: RequestWithJwt<PdaJwt>, res: Response, next: Function) => {
	if (!req.jwt) return res.status(401).send("401 - Unauthorized");
	if (!req.jwt.matricule || !req.jwt.codeVille) return res.status(401).send("403 - Forbidden");
	if (req.param.hasOwnProperty("cityId") && req.params.cityId !== req.jwt.codeVille)
		return res.status(403).send(`403 - Forbidden on city ${req.params.cityId}`);
	next();
};
