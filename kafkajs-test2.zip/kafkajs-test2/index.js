const express =require('express');
const app = express();
const port = 3001;
const { Kafka } = require('kafkajs')

const kafka = new Kafka({
  clientId: 'my-app',
  brokers: ['localhost:9092'], // /!\  Several hosts can be placed here to make the system more resilient
});

const producer = kafka.producer();
const consumer = kafka.consumer({ groupId: 'test-group-app2' });

const consumerSetup = async () => {
    await consumer.connect()
    await consumer.subscribe({ topic: 'Test', fromBeginning: true })

    await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
        console.log({
            value: message.value.toString(),
        })
    },
    })
};
consumerSetup().catch(() => {
    console.log("Got error in setup consumer")
})

// Define a route for the root URL
app.get('/hello', async (req, res) => {
    await producer.connect()
    await producer.send({
        topic: 'Test',
        messages: [
            { value: 'Hello KafkaJS user!' },
        ],
    });
    res.send('Hello, World!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
})